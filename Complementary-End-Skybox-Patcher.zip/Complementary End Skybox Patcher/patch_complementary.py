#!/usr/bin/env python3
"""Add the Iteration T End skybox to a compatible Complementary shader-pack copy."""
from __future__ import annotations
import argparse
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
MODULE_REL = Path("shaders/lib/atmospherics/iterationTEndSky.glsl")

SETTINGS = r'''    // End Skybox settings
    #define END_T_SKY_BRIGHTNESS 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255 260 265 270 275 280 285 290 295 300]
    #define END_T_LIGHT_BRIGHTNESS 150 //[50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250]
    #define END_T_DIRECT_LIGHT_BRIGHTNESS 350 //[100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255 260 265 270 275 280 285 290 295 300 305 310 315 320 325 330 335 340 345 350 355 360 365 370 375 380 385 390 395 400 405 410 415 420 425 430 435 440 445 450 455 460 465 470 475 480 485 490 495 500 505 510 515 520 525 530 535 540 545 550 555 560 565 570 575 580 585 590 595 600 605 610 615 620 625 630 635 640 645 650 655 660 665 670 675 680 685 690 695 700 705 710 715 720 725 730 735 740 745 750 755 760 765 770 775 780 785 790 795 800 805 810 815 820 825 830 835 840 845 850 855 860 865 870 875 880 885 890 895 900 905 910 915 920 925 930 935 940 945 950 955 960 965 970 975 980 985 990 995 1000]
    #define END_T_LIGHT_NEUTRAL 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]
    #define END_T_BLACK_HOLE 1 //[0 1]
    #define END_T_BLACK_HOLE_INTENSITY 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255 260 265 270 275 280 285 290 295 300]
    #define END_T_BLACK_HOLE_ELEVATION 30 //[-45 -40 -35 -30 -25 -20 -15 -10 -5 0 5 10 15 20 25 30 35 40 45]
    #define END_T_DISC_TILT_LEFT_RIGHT -15 //[-90 -85 -80 -75 -70 -65 -60 -55 -50 -45 -40 -35 -30 -25 -20 -15 -10 -5 0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90]
    #define END_T_DISC_TILT_UP_DOWN 20 //[-90 -85 -80 -75 -70 -65 -60 -55 -50 -45 -40 -35 -30 -25 -20 -15 -10 -5 0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90]
    #define END_T_WARP_STRENGTH 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200]
    #define END_T_STARS 1 //[0 1]
    #define END_T_STAR_INTENSITY 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255 260 265 270 275 280 285 290 295 300]
    #define END_T_PLANET 1 //[0 1]
    #define END_T_PLANET_INTENSITY 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255 260 265 270 275 280 285 290 295 300]
    #define END_T_PLANET_ELEVATION 0 //[-60 -55 -50 -45 -40 -35 -30 -25 -20 -15 -10 -5 0 5 10 15 20 25 30 35 40 45 50 55 60]
    #define END_T_PLANET_ORBIT_PHASE 130 //[-180 -175 -170 -165 -160 -155 -150 -145 -140 -135 -130 -125 -120 -115 -110 -105 -100 -95 -90 -85 -80 -75 -70 -65 -60 -55 -50 -45 -40 -35 -30 -25 -20 -15 -10 -5 0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180]
    #define END_T_PLANET_CYCLE 20.0 //[1.0 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0 95.0 100.0 105.0 110.0 115.0 120.0 125.0 130.0 135.0 140.0 145.0 150.0 155.0 160.0 165.0 170.0 175.0 180.0 185.0 190.0 195.0 200.0 205.0 210.0 215.0 220.0 225.0 230.0 235.0 240.0 245.0 250.0]
    #define END_T_ANIMATION_SPEED 100 //[0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200]
    #define END_T_SKY_ROTATION 0 //[-180 -175 -170 -165 -160 -155 -150 -145 -140 -135 -130 -125 -120 -115 -110 -105 -100 -95 -90 -85 -80 -75 -70 -65 -60 -55 -50 -45 -40 -35 -30 -25 -20 -15 -10 -5 0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180]
    #define END_T_SKY_TILT 0 //[-90 -85 -80 -75 -70 -65 -60 -55 -50 -45 -40 -35 -30 -25 -20 -15 -10 -5 0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90]
    #define END_T_DOPPLER_EFFECT
'''

LANG = r''' 

screen.ITERATION_T=End Skybox
screen.ITERATION_T.comment=Controls the planet, stars, black hole, accretion disc and End-sky lighting.

# End Skybox
option.END_T_SKY_BRIGHTNESS=End Sky Brightness
option.END_T_SKY_BRIGHTNESS.comment=Sets the brightness of the complete End sky, including the stars, planet, rings and black hole. Default: 100%.
option.END_T_LIGHT_BRIGHTNESS=End Lighting Brightness
option.END_T_LIGHT_BRIGHTNESS.comment=Sets the brightness of End block lighting and ambient light. Default: 150%.
option.END_T_DIRECT_LIGHT_BRIGHTNESS=End Direct Light Brightness
option.END_T_DIRECT_LIGHT_BRIGHTNESS.comment=Sets the strength of the direct End light shining from the black-hole direction. Default: 350%.
option.END_T_LIGHT_NEUTRAL=End Light Colour Neutrality
option.END_T_LIGHT_NEUTRAL.comment=Controls the purple tint on End lighting and all End-sky effects. 100 keeps the sky untinted; lower values add more purple. Default: 100 (no extra sky tint).
option.END_T_BLACK_HOLE=Black Hole and Accretion Disc
option.END_T_BLACK_HOLE.comment=Shows or hides the black hole and its accretion disc. Default: On.
value.END_T_BLACK_HOLE.0=Off
value.END_T_BLACK_HOLE.1=On
option.END_T_BLACK_HOLE_INTENSITY=Black Hole Intensity
option.END_T_BLACK_HOLE_INTENSITY.comment=Changes the brightness of the black hole and accretion disc. Default: 100%.
option.END_T_BLACK_HOLE_ELEVATION=Black Hole Height
option.END_T_BLACK_HOLE_ELEVATION.comment=Moves the black hole and its disc higher or lower in the sky. Default: 30 degrees.
option.END_T_DISC_TILT_LEFT_RIGHT=Accretion Disc Left/Right Tilt
option.END_T_DISC_TILT_LEFT_RIGHT.comment=Tilts the accretion disc from side to side. Default: -15 degrees.
option.END_T_DISC_TILT_UP_DOWN=Accretion Disc Up/Down Tilt
option.END_T_DISC_TILT_UP_DOWN.comment=Tilts the accretion disc up or down. Default: 20 degrees.
option.END_T_WARP_STRENGTH=Gravitational Lensing
option.END_T_WARP_STRENGTH.comment=Controls how strongly light bends around the black hole. Default: 100%.
option.END_T_STARS=Stars
option.END_T_STARS.comment=Shows or hides the generated star field. Default: On.
value.END_T_STARS.0=Off
value.END_T_STARS.1=On
option.END_T_STAR_INTENSITY=Star Intensity
option.END_T_STAR_INTENSITY.comment=Changes how bright the stars appear. Default: 100%.
option.END_T_PLANET=Ringed Planet
option.END_T_PLANET.comment=Shows or hides the planet and its rings. Default: On.
value.END_T_PLANET.0=Off
value.END_T_PLANET.1=On
option.END_T_PLANET_INTENSITY=Planet Intensity
option.END_T_PLANET_INTENSITY.comment=Changes the brightness of the planet and its rings. Default: 100%.
option.END_T_PLANET_ELEVATION=Planet Orbit Tilt
option.END_T_PLANET_ELEVATION.comment=Changes the tilt of the path the planet follows. Default: 0 degrees.
option.END_T_PLANET_ORBIT_PHASE=Planet Orbit Phase
option.END_T_PLANET_ORBIT_PHASE.comment=Sets where the planet starts along its orbit. Default: 130 degrees.
option.END_T_PLANET_CYCLE=Planet Cycle (minutes)
option.END_T_PLANET_CYCLE.comment=Sets how many minutes one full planet orbit takes when Animation Speed is 100%. Default: 20 minutes. Higher values make the orbit slower; 250 minutes pauses it.
option.END_T_ANIMATION_SPEED=Animation Speed
option.END_T_ANIMATION_SPEED.comment=Changes the speed of the planet, stars and accretion disc animations. Default: 100%.
option.END_T_SKY_ROTATION=Sky Rotation
option.END_T_SKY_ROTATION.comment=Rotates the complete End sky left or right around the horizon. Default: 0 degrees.
option.END_T_SKY_TILT=Sky Tilt
option.END_T_SKY_TILT.comment=Tilts the complete End sky up or down. Default: 0 degrees.
'''

# Exact helpers copied from Iteration T Utilities.glsl. Only renamed to avoid collisions.
HELPERS = r'''
float IT_remapSaturate(float x, float e0, float e1) {
    return IT_SATURATE((x - e0) / (e1 - e0));
}

float IT_atan2(vec2 v) {
    return v.x == 0.0 ?
        (1.0 - step(abs(v.y), 0.0)) * sign(v.y) * 1.57079632679 :
        atan(v.y / v.x) + step(v.x, 0.0) * sign(v.y) * IT_PI;
}

vec3 IT_Blackbody(float temperature) {
    const mat2x4 splineX = mat2x4(-0.2661293e9, -0.2343589e6, 0.8776956e3, 0.179910,
                                  -3.0258469e9,  2.1070479e6, 0.2226347e3, 0.240390);
    const mat3x4 splineY = mat3x4(-1.1063814, -1.34811020, 2.18555832, -0.20219683,
                                  -0.9549476, -1.37418593, 2.09137015, -0.16748867,
                                   3.0817580, -5.87338670, 3.75112997, -0.37001483);

    float rt = 1.0 / temperature;
    float rt2 = rt * rt;
    vec4 coeffX = vec4(rt2 * rt, rt2, rt, 1.0);
    float x = dot(coeffX, temperature < 4000.0 ? splineX[0] : splineX[1]);
    float x2 = x * x;
    vec4 coeffY = vec4(x2 * x, x2, x, 1.0);
    float z = 1.0 / dot(coeffY, temperature < 2222.0 ? splineY[0] : temperature < 4000.0 ? splineY[1] : splineY[2]);
    vec3 xyz = vec3(x * z, 1.0, z);
    xyz.z -= xyz.x + 1.0;
    const mat3 xyzToSrgb = mat3(3.24097, -0.96924, 0.05563,
                                -1.53738, 1.87597, -0.20398,
                                -0.49861, 0.04156, 1.05697);
    return max(xyzToSrgb * xyz, vec3(0.0));
}

vec3 IT_RayPlaneIntersection(vec3 ori, vec3 dir, vec3 normal) {
    float rayPlaneAngle = dot(dir, normal);
    float planeRayDist = 1e8;
    vec3 intersectionPos = dir * planeRayDist;
    if (rayPlaneAngle > 0.0001 || rayPlaneAngle < -0.0001) {
        planeRayDist = dot(-ori, normal) / rayPlaneAngle;
        intersectionPos = ori + dir * planeRayDist;
    }
    return intersectionPos;
}

vec2 IT_RaySphereIntersection(vec3 ori, vec3 dir, float radius) {
    float b = dot(ori, dir);
    float c = -radius * radius + dot(ori, ori);
    float d = b * b - c;
    vec2 intersection = vec2(1e10, -1e10);
    if (d >= 0.0) {
        d = sqrt(d);
        intersection = vec2(-b - d, -b + d);
    }
    return intersection;
}

float IT_MiePhaseFunction(float g, float nu) {
    float gg = g * g;
    float k = 0.1193662 * (1.0 - gg) / (2.0 + gg);
    return k * (1.0 + nu * nu) * pow(1.0 + gg - 2.0 * g * nu, -1.5);
}

float IT_InterleavedGradientNoise(vec2 c) {
    return fract(52.9829189 * fract(0.06711056 * c.x + 0.00583715 * c.y));
}

vec2 IT_BlueNoiseTemproal() {
    return fract(texelFetch(noisetex, ivec2(gl_FragCoord.xy) % 64, 0).xy +
                 vec2(IT_GOLDEN_RATIO, IT_PLASTIC_RATIO) * vec2(frameCounter % 64));
}
'''


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8-sig")

def write_text(p: Path, t: str) -> None:
    p.write_text(t, encoding="utf-8", newline="\n")

def safe_extract(z: Path, dest: Path) -> None:
    with zipfile.ZipFile(z) as zf:
        for info in zf.infolist():
            target = (dest / info.filename).resolve()
            if dest.resolve() not in target.parents and target != dest.resolve():
                raise RuntimeError(f"Unsafe path in ZIP: {info.filename}")
        zf.extractall(dest)

def find_pack_root(root: Path) -> Path:
    if (root / "shaders/lib/common.glsl").is_file():
        return root
    candidates = sorted({p.parents[2] for p in root.rglob("shaders/lib/common.glsl")}, key=lambda x: (len(x.parts), str(x)))
    if len(candidates) != 1:
        raise RuntimeError("Select the shader-pack root, or a ZIP containing exactly one shaders/lib/common.glsl.")
    return candidates[0]

def make_zip(pack_root: Path, output: Path) -> None:
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=7) as zf:
        for p in sorted(pack_root.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(pack_root).as_posix())

def ensure_after(text: str, anchor: str, insertion: str, label: str) -> str:
    if insertion in text:
        return text
    idx = text.find(anchor)
    if idx < 0:
        raise RuntimeError(f"Could not find include anchor for {label}: {anchor}")
    idx += len(anchor)
    return text[:idx] + "\n" + insertion + text[idx:]

def find_matching_preprocessor_end(text: str, start: int) -> int:
    """Return end offset after matching #endif for an #if directive at start."""
    lines = text[start:].splitlines(keepends=True)
    depth = 0
    offset = start
    started = False
    for line in lines:
        stripped = line.lstrip()
        if re.match(r"#\s*(if|ifdef|ifndef)\b", stripped):
            depth += 1
            started = True
        elif re.match(r"#\s*endif\b", stripped):
            depth -= 1
            if started and depth == 0:
                return offset + len(line)
        offset += len(line)
    raise RuntimeError("Unbalanced preprocessor block while patching")

def replace_preprocessor_block(text: str, start_needle: str, replacement: str, label: str) -> str:
    start = text.find(start_needle)
    if start < 0:
        raise RuntimeError(f"Could not find {label} start")
    # Start must be the beginning of a preprocessor line.
    line_start = text.rfind("\n", 0, start) + 1
    end = find_matching_preprocessor_end(text, line_start)
    return text[:line_start] + replacement + text[end:]


def add_module_include(path: Path) -> None:
    text = read_text(path)
    block = '#if defined END && defined FRAGMENT_SHADER\n    #include "/lib/atmospherics/iterationTEndSky.glsl"\n#endif'
    if block in text:
        return
    text = ensure_after(text, '#include "/lib/common.glsl"', block, path.name)
    write_text(path, text)


def patch_common(shaders: Path) -> None:
    p = shaders / "lib/common.glsl"
    text = read_text(p)
    if "#define END_T_SKY_BRIGHTNESS" not in text:
        anchor = "//User Settings//"
        text = ensure_after(text, anchor, "\n" + SETTINGS.rstrip(), "End Skybox settings in common.glsl")
    # Ensure all Iteration T lighting controls are present in the common settings block.
    if "#define END_T_LIGHT_BRIGHTNESS" not in text:
        m = re.search(r"(?m)^(\s*#define END_T_SKY_BRIGHTNESS[^\n]*\n)", text)
        if not m:
            raise RuntimeError("common.glsl: cannot insert End lighting brightness setting")
        text = text[:m.end()] + "    #define END_T_LIGHT_BRIGHTNESS 150 //[50 75 100 110 125 140 150 175 200 250]\n" + text[m.end():]
    if "#define END_T_LIGHT_NEUTRAL" not in text:
        m = re.search(r"(?m)^(\s*#define END_T_LIGHT_BRIGHTNESS[^\n]*\n)", text)
        if not m:
            raise RuntimeError("common.glsl: cannot insert End light-neutrality setting")
        text = text[:m.end()] + "    #define END_T_LIGHT_NEUTRAL 100 //[0 20 40 60 80 100]\n" + text[m.end():]
    if "#define END_T_DIRECT_LIGHT_BRIGHTNESS" not in text:
        m = re.search(r"(?m)^(\s*#define END_T_LIGHT_BRIGHTNESS[^\n]*\n)", text)
        if not m:
            raise RuntimeError("common.glsl: cannot insert direct End lighting brightness setting")
        text = text[:m.end()] + "    #define END_T_DIRECT_LIGHT_BRIGHTNESS 350 //[100 125 150 175 200 250 300 400 500 600 800 1000]\n" + text[m.end():]

    # Keep Euphoria's own End fog system, but make its background fog fallback dark-space
    # instead of allowing the retired purple endSkyColor to leak into other End effects.
    old = re.compile(
        r"(?m)^\s*const\s+vec3\s+originalEndSkyColor\s*=.*?;\s*\n\s*vec3\s+endSkyColor\s*=.*?;"
    )
    text, n = old.subn("    const vec3 originalEndSkyColor = vec3(0.0005, 0.0007, 0.0012);\n    vec3 endSkyColor = originalEndSkyColor; // Iteration T deep-space fallback for Euphoria fog", text, count=1)
    if n == 0:
        # Base Complementary has a shorter declaration in some builds; only require that
        # a declaration exists and set it to a dark fallback.
        text, n2 = re.subn(r"(?m)^\s*(?:const\s+)?vec3\s+endSkyColor\s*=.*?;", "    const vec3 endSkyColor = vec3(0.0005, 0.0007, 0.0012);", text, count=1)
        if n2 == 0:
            raise RuntimeError("Could not locate endSkyColor in common.glsl")
    write_text(p, text)


def patch_skybasic(shaders: Path) -> None:
    p = shaders / "program/gbuffers_skybasic.glsl"
    text = read_text(p)
    add_module_include(p)
    text = read_text(p)
    anchor = "    vec4 color = vec4(glColor.rgb, 1.0);"
    inject = r'''    vec4 color = vec4(glColor.rgb, 1.0);

    #ifdef END
        // Skybasic leaves vanilla glColor untouched in the End by default.
        // Reconstruct this fragment's view ray and run Iteration T's original sky.
        vec4 endScreenPos = vec4(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z, 1.0);
        vec4 endViewPos = gbufferProjectionInverse * (endScreenPos * 2.0 - 1.0);
        endViewPos /= endViewPos.w;
        vec3 endWorldRay = normalize(mat3(gbufferModelViewInverse) * normalize(endViewPos.xyz));
        color.rgb = IT_GetEndSkyGamma(endWorldRay);
        color.a = 1.0;
    #endif'''
    if "IT_GetEndSkyGamma(endWorldRay)" not in text:
        if anchor not in text:
            raise RuntimeError("gbuffers_skybasic.glsl: missing initial colour assignment")
        text = text.replace(anchor, inject, 1)
    write_text(p, text)


def patch_skytextured(shaders: Path) -> None:
    p = shaders / "program/gbuffers_skytextured.glsl"
    text = read_text(p)
    add_module_include(p)
    text = read_text(p)
    old = "    #ifdef END\n        vec4 color = vec4(endSkyColor, 1.0);\n    #endif"
    new = r'''    #ifdef END
        vec4 endScreenPos = vec4(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z, 1.0);
        vec4 endViewPos = gbufferProjectionInverse * (endScreenPos * 2.0 - 1.0);
        endViewPos /= endViewPos.w;
        vec3 endWorldRay = normalize(mat3(gbufferModelViewInverse) * normalize(endViewPos.xyz));
        vec4 color = vec4(IT_GetEndSkyGamma(endWorldRay), 1.0);
    #endif'''
    if "IT_GetEndSkyGamma(endWorldRay)" not in text:
        if old not in text:
            raise RuntimeError("gbuffers_skytextured.glsl: missing original END endSkyColor branch")
        text = text.replace(old, new, 1)
    write_text(p, text)


def remove_deferred_legacy_includes(text: str) -> str:
    for line in [
        '#include "/lib/shaderSettings/enderStars.glsl"',
        '#include "/lib/shaderSettings/enderNebula.glsl"',
    ]:
        text = re.sub(r"(?m)^\s*" + re.escape(line) + r"\s*\n", "", text)
    for opening in [
        "#if defined END && defined END_STARS",
        "#if defined END && END_NEBULA > 0",
        "#if defined END && BLACK_HOLE > 0",
    ]:
        pos = text.find(opening)
        if pos >= 0:
            ls = text.rfind("\n", 0, pos) + 1
            end = find_matching_preprocessor_end(text, ls)
            text = text[:ls] + text[end:]
    return text


def patch_deferred(shaders: Path) -> None:
    p = shaders / "program/deferred1.glsl"
    text = read_text(p)
    add_module_include(p)
    text = read_text(p)
    text = remove_deferred_legacy_includes(text)

    # The old precomputed End black-hole mask is only used by the retired renderer.
    old_mask = re.compile(
        r"(?ms)^\s*float\s+blackHoleEventHorizon\s*=\s*1\.0\s*;\s*\n"
        r"\s*#if\s+BLACK_HOLE\s*>\s*0\s*&&\s*defined\s+END\s*\n"
        r".*?^\s*#endif\s*\n"
    )
    text, mask_count = old_mask.subn("", text, count=1)

    old_start = "            #ifdef END\n                color.rgb = endSkyColor;"
    new_block = r'''            #ifdef END
                vec3 endWorldRay = normalize(mat3(gbufferModelViewInverse) * normalize(viewPos.xyz));
                color.rgb = IT_GetEndSkyGamma(endWorldRay);

                // Keep Euphoria's separate End-flash ambient lighting feature.
                #if (MC_VERSION >= 12109 || ANGELICA_VERSION >= 20155000) && defined IS_IRIS && EP_END_FLASH > 0
                    if (endFlashIntensityM > 0.0) {
                        color.rgb += DrawEndFlash(nViewPos, VdotU, dither);
                    }
                #endif

                color.rgb *= 1.0 - maxBlindnessDarkness;
                #ifdef ATM_COLOR_MULTS
                    color.rgb *= atmColorMult;
                #endif
            #endif
'''
    if "IT_GetEndSkyGamma(endWorldRay)" not in text:
        text = replace_preprocessor_block(text, old_start, new_block, "deferred1 End sky branch")

    # Delete the old Euphoria End nebula overlay block; the port owns the complete sky.
    nebula_start = "    #if defined END && END_NEBULA > 0"
    pos = text.find(nebula_start)
    if pos >= 0:
        ls = text.rfind("\n", 0, pos) + 1
        end = find_matching_preprocessor_end(text, ls)
        text = text[:ls] + text[end:]

    write_text(p, text)


def patch_reflection(shaders: Path) -> None:
    p = shaders / "lib/materials/materialMethods/reflectionBackground.glsl"
    text = read_text(p)
    # The shared methods file is included from fragment programs only in these paths.
    include = '#if defined END && defined FRAGMENT_SHADER && !defined VOXY_TRANSLUCENT\n    #include "/lib/atmospherics/iterationTEndSky.glsl"\n#endif'
    if include not in text:
        text = include + "\n" + text

    # Voxy's custom translucent fragment interface has no texCoord varying.
    # Do not import End volumetricLight.glsl into that program; it samples texCoord.
    old_volumetric_guard = "#if defined END && (defined COMPOSITE || defined GBUFFERS_WATER || defined VOXY_TRANSLUCENT)"
    new_volumetric_guard = "#if defined END && (defined COMPOSITE || defined GBUFFERS_WATER)"
    if old_volumetric_guard in text:
        text = text.replace(old_volumetric_guard, new_volumetric_guard, 1)
    elif new_volumetric_guard not in text:
        raise RuntimeError("reflectionBackground.glsl: cannot locate End volumetric include guard")

    # Retain Euphoria's End beams (a separate volumetric effect) in normal Iris
    # composite/water passes, but remove its old stars and nebula reflection helpers.
    text = re.sub(r'(?m)^\s*#include\s+"/lib/atmospherics/enderStars\.glsl"\s*\n', "", text)
    text = re.sub(r'(?m)^\s*#include\s+"/lib/atmospherics/enderNebula\.glsl"\s*\n', "", text)

    start = "    #elif defined END\n"
    pos = text.find(start)
    if pos < 0:
        raise RuntimeError("reflectionBackground.glsl: no END reflection branch found")
    marker = "    #else\n        vec3 skyReflection = vec3(0.0);\n    #endif"
    end = text.find(marker, pos)
    if end < 0:
        raise RuntimeError("reflectionBackground.glsl: cannot find end of END reflection branch")
    replacement = r'''    #elif defined END
        #ifdef VOXY_TRANSLUCENT
            // Avoid compiling the full End raymarch inside Voxy's injected terrain fragment.
            vec3 skyReflection = endSkyColor * skyLightFactor;
        #else
            vec3 endWorldReflectionRay = normalize(mat3(gbufferModelViewInverse) * nViewPosR);
            vec3 skyReflection = IT_GetEndSkyReflectionGamma(endWorldReflectionRay) * skyLightFactor;
        #endif

        // Preserve Complementary/Euphoria's separate End volumetric-beam pass.
        // It must be declared in this branch before it is added to the sky reflection.
        #if defined COMPOSITE || defined GBUFFERS_WATER
            #ifdef COMPOSITE
                float vlFactorM = vlFactor;
            #elif defined GBUFFERS_WATER
                float vlFactorM = texelFetch(colortex5, ivec2(viewWidth-1, viewHeight-1), 0).a;
            #endif

            vec3 translucentMult = vec3(1.0);
            float lViewPos = 100000.0;
            float lViewPos1 = 100000.0;
            vec4 volumetricEffect = GetVolumetricLight(vlFactorM, translucentMult, lViewPos, lViewPos1, nViewPosR, RVdotS, RVdotU, z0, z0, z0, dither);
            volumetricEffect.rgb = pow(volumetricEffect.rgb, vec3(1.0 / 2.2));

            #ifdef COMPOSITE
                volumetricEffect.rgb *= 1.25;
            #endif

            // DrawEnderBeams() itself respects Euphoria's END_BEAMS toggle.
            skyReflection += volumetricEffect.rgb * skyLightFactor;
        #endif

        #ifdef ATM_COLOR_MULTS
            skyReflection *= atmColorMult;
        #endif
'''
    text = text[:pos] + replacement + text[end:]
    write_text(p, text)



def patch_end_light_direction(shaders: Path) -> None:
    """Use the elevated Iteration T black-hole axis for sky, direct light and shadows."""
    p = shaders / "lib/util/commonFunctions.glsl"
    text = read_text(p)
    helper = r'''#elif defined END
    // Scene rotation shared by the visible sky, direct light and shadow camera.
    // At zero settings this is the identity, matching Iteration T's original axes.
    mat3 GetIterationTEndSceneRotation() {
        float yaw = radians(130.0 + float(END_T_SKY_ROTATION));
        float pitch = radians(float(END_T_SKY_TILT));
        mat3 rotY = mat3(cos(yaw), 0.0, -sin(yaw),
                         0.0, 1.0, 0.0,
                         sin(yaw), 0.0, cos(yaw));
        mat3 rotX = mat3(1.0, 0.0, 0.0,
                         0.0, cos(pitch), sin(pitch),
                         0.0, -sin(pitch), cos(pitch));
        return rotY * rotX;
    }

    vec3 GetIterationTEndBlackHoleDirectionLocal() {
        // Inverse End shadow rotation vector from the original Iteration T source.
        // Apply elevation around the local horizon while preserving the original azimuth.
        vec3 originalDirection = normalize(vec3(-0.85649968, -0.27635565, 0.43593102));
        float azimuth = atan(originalDirection.x, originalDirection.z);
        float elevation = asin(clamp(originalDirection.y, -1.0, 1.0)) + radians(float(END_T_BLACK_HOLE_ELEVATION));
        return normalize(vec3(cos(elevation) * sin(azimuth),
                              sin(elevation),
                              cos(elevation) * cos(azimuth)));
    }

    vec3 GetIterationTEndLightDirection() {
        // Positive Black Hole Elevation raises the original direction; zero is source-faithful.
        return normalize(GetIterationTEndSceneRotation() * GetIterationTEndBlackHoleDirectionLocal());
    }

    float GetIterationTPlanetDirectVisibility() {
        #if END_T_PLANET > 0
            if (END_T_PLANET_INTENSITY <= 0) return 1.0;
            float planetPhaseOffset = 0.282 + float(END_T_PLANET_ORBIT_PHASE) / 360.0;
            float planetTime = (END_T_PLANET_CYCLE >= 250.0)
                ? fract(planetPhaseOffset) * 6.28318530718
                : fract(frameTimeCounter * ((1.0 / 60.0) / max(END_T_PLANET_CYCLE, 1.0)) * (END_T_ANIMATION_SPEED * 0.01) + planetPhaseOffset) * 6.28318530718;
            // Match the fixed mean orbit-plane angle used by the rendered planet.
            // Only the horizontal orbit phase changes; apparent height stays fixed.
            float angleX = -1.67079633 - radians(float(END_T_PLANET_ELEVATION));
            float angleY = planetTime;
            mat3 eyeRotationX = mat3(1.0, 0.0, 0.0,
                                     0.0, cos(angleX), -sin(angleX),
                                     0.0, sin(angleX), cos(angleX));
            mat3 eyeRotationY = mat3(cos(angleY), 0.0, sin(angleY),
                                     0.0, 1.0, 0.0,
                                     -sin(angleY), 0.0, cos(angleY));
            mat3 eyeRotation = eyeRotationX * eyeRotationY;
            // Convert the planet's centre ray from its local frame into the world sky frame.
            vec3 planetCentreLocal = normalize(transpose(eyeRotation) * vec3(0.0, -1.0, 0.0));
            vec3 planetCentreDirection = normalize(GetIterationTEndSceneRotation() * planetCentreLocal);
            vec3 blackHoleDirection = GetIterationTEndLightDirection();
            float angularSeparation = acos(clamp(dot(planetCentreDirection, blackHoleDirection), -1.0, 1.0));
            // Iteration T's original eye offset is 1.75 planet radii.
            float planetAngularRadius = asin(1.0 / 1.75);
            float occultation = 1.0 - smoothstep(planetAngularRadius - radians(1.5),
                                                  planetAngularRadius + radians(1.5),
                                                  angularSeparation);
            return clamp(1.0 - occultation * (END_T_PLANET_INTENSITY * 0.01), 0.0, 1.0);
        #else
            return 1.0;
        #endif
    }
'''
    marker = "#elif defined END\n"
    if "GetIterationTPlanetDirectVisibility()" not in text:
        if marker not in text:
            raise RuntimeError("commonFunctions.glsl: could not find the End-sky lighting integration point")
        text = text.replace(marker, helper, 1)

    replacement = "#define GetSunVector() normalize(mat3(gbufferModelView) * GetIterationTEndLightDirection())"
    lines = text.splitlines()
    replaced = 0
    for i, line in enumerate(lines):
        if "#define GetSunVector()" in line and ("endFlashPosition" in line or "SUN_ROTATION_DATA * 2000.0" in line or "GetIterationTEndLightDirection" in line):
            indent = line[:len(line) - len(line.lstrip())]
            lines[i] = indent + replacement
            replaced += 1
    if replaced == 0 and replacement not in text:
        raise RuntimeError("commonFunctions.glsl: could not locate End GetSunVector() macros")
    write_text(p, "\n".join(lines) + "\n")


def patch_end_shadow_matrices(shaders: Path) -> None:
    # Rotate both the End shadow-map writer and its readers to the black-hole axis.
    space = shaders / "lib/util/spaceConversion.glsl"
    text = read_text(space)
    function = r'''#ifdef END
// Build an End shadow camera whose light-facing axis is Iteration T's black-hole direction.
// Keep Iris's current snapped camera origin and projection bounds, but replace its rotation.
mat4 GetIterationTEndShadowModelView() {
    vec3 lightDirection = GetIterationTEndLightDirection();
    vec3 forward = -lightDirection;
    vec3 referenceUp = vec3(0.0, 1.0, 0.0);
    vec3 right = normalize(cross(forward, referenceUp));
    vec3 up = normalize(cross(right, forward));
    mat3 worldToShadow = transpose(mat3(right, up, lightDirection));
    vec3 shadowCameraPosition = shadowModelViewInverse[3].xyz;
    mat4 result = mat4(worldToShadow);
    result[3] = vec4(-worldToShadow * shadowCameraPosition, 1.0);
    return result;
}
#endif

'''
    if "GetIterationTEndShadowModelView()" not in text:
        anchor_line = "#define projMAD(m, v) (diagonal3(m) * (v) + (m)[3].xyz)"
        if anchor_line not in text:
            raise RuntimeError("spaceConversion.glsl: missing projMAD helper")
        text = text.replace(anchor_line, anchor_line + "\n\n" + function.rstrip(), 1)
    old = '''vec3 PlayerToShadow(vec3 pos) {
    vec3 shadowpos = mat3(shadowModelView) * pos + shadowModelView[3].xyz;
    return projMAD(shadowProjection, shadowpos);
}'''
    new = '''vec3 PlayerToShadow(vec3 pos) {
    #ifdef END
        mat4 endShadowModelView = GetIterationTEndShadowModelView();
        vec3 shadowpos = mat3(endShadowModelView) * pos + endShadowModelView[3].xyz;
    #else
        vec3 shadowpos = mat3(shadowModelView) * pos + shadowModelView[3].xyz;
    #endif
    return projMAD(shadowProjection, shadowpos);
}'''
    if new not in text:
        if old not in text:
            raise RuntimeError("spaceConversion.glsl: cannot locate PlayerToShadow()")
        text = text.replace(old, new, 1)
    write_text(space, text)

    shadow = shaders / "program/shadow.glsl"
    text = read_text(shadow)
    old_glpos = "    gl_Position = shadowProjection * shadowModelView * position;"
    new_glpos = '''    #ifdef END
        gl_Position = shadowProjection * GetIterationTEndShadowModelView() * position;
    #else
        gl_Position = shadowProjection * shadowModelView * position;
    #endif'''
    if new_glpos not in text:
        if old_glpos not in text:
            raise RuntimeError("program/shadow.glsl: cannot locate shadow-map output transform")
        text = text.replace(old_glpos, new_glpos, 1)
    write_text(shadow, text)


def patch_end_lighting(shaders: Path) -> None:
    """Brighten and neutralise End lighting using declarations only.

    lightAndAmbientColors.glsl is included at global scope by several shader
    programs. Therefore every generated statement in its End branch must be a
    declaration/initializer; ordinary assignments are invalid GLSL at that
    location and cause Iris's source parser to fail.
    """
    p = shaders / "lib/colors/lightAndAmbientColors.glsl"
    text = read_text(p)
    end_start = text.find("#elif defined END")
    if end_start < 0:
        raise RuntimeError("lightAndAmbientColors.glsl: could not locate the End lighting branch")
    end_stop = text.find("#endif", end_start)
    if end_stop < 0:
        raise RuntimeError("lightAndAmbientColors.glsl: End lighting branch is not closed")
    end_block = text[end_start:end_stop]

    # Neutralise the derived direct-light colour without a global-scope
    # assignment. Keep the original expression intact as endLightColorBase.
    if "endLightNeutral" not in end_block:
        pattern = re.compile(r"(?m)^([ \t]*)vec3[ \t]+endLightColor[ \t]*=[ \t]*(.*?);[ \t]*(?://[^\r\n]*)?$")
        matches = list(pattern.finditer(end_block))
        if len(matches) != 1:
            raise RuntimeError(f"lightAndAmbientColors.glsl: expected one End endLightColor declaration, found {len(matches)}")
        m = matches[0]
        indent, rhs = m.group(1), m.group(2)
        replacement = (
            f"{indent}vec3 endLightColorBase = {rhs};\n"
            f"{indent}float endLightLuma = dot(max(endLightColorBase, vec3(0.0)), vec3(0.2126, 0.7152, 0.0722));\n"
            f"{indent}vec3 endLightNeutral = endLightLuma * vec3(1.0, 0.98, 0.94);\n"
            f"{indent}vec3 endLightColor = mix(endLightColorBase, endLightNeutral, END_T_LIGHT_NEUTRAL * 0.01);"
        )
        end_block = end_block[:m.start()] + replacement + end_block[m.end():]

    # Euphoria derives ambientColor from a configurable tint; Complementary
    # derives it directly from endLightColor. Neutralise the final expression
    # with declarations, then apply the brightness multiplier in the final
    # initializer. This avoids illegal global-scope assignments.
    if "endAmbientNeutral" not in end_block:
        ambient_pattern = re.compile(r"(?m)^([ \t]*)vec3[ \t]+ambientColor[ \t]*=[ \t]*(.*?);[ \t]*(?://[^\r\n]*)?$")
        ambient_matches = list(ambient_pattern.finditer(end_block))
        if len(ambient_matches) != 1:
            raise RuntimeError(f"lightAndAmbientColors.glsl: expected one final End ambientColor declaration, found {len(ambient_matches)}")
        a = ambient_matches[0]
        indent, rhs = a.group(1), a.group(2)
        ambient_replacement = (
            f"{indent}vec3 endAmbientBase = {rhs};\n"
            f"{indent}float endAmbientLuma = dot(max(endAmbientBase, vec3(0.0)), vec3(0.2126, 0.7152, 0.0722));\n"
            f"{indent}vec3 endAmbientNeutral = endAmbientLuma * vec3(1.0, 0.98, 0.94);\n"
            f"{indent}vec3 ambientColor = mix(endAmbientBase, endAmbientNeutral, END_T_LIGHT_NEUTRAL * 0.01) * (END_T_LIGHT_BRIGHTNESS * 0.01);"
        )
        end_block = end_block[:a.start()] + ambient_replacement + end_block[a.end():]

    light_pattern = re.compile(r"(?m)^([ \t]*)vec3[ \t]+lightColor[ \t]*=[ \t]*(.*?);[ \t]*(?://[^\r\n]*)?$")
    light_matches = list(light_pattern.finditer(end_block))
    if len(light_matches) != 1:
        raise RuntimeError(f"lightAndAmbientColors.glsl: expected one End lightColor declaration, found {len(light_matches)}")
    m = light_matches[0]
    indent, rhs = m.group(1), m.group(2)
    if "END_T_LIGHT_BRIGHTNESS" not in rhs:
        light_replacement = f"{indent}vec3 lightColor = ({rhs}) * (END_T_LIGHT_BRIGHTNESS * 0.01) * (END_T_DIRECT_LIGHT_BRIGHTNESS * 0.01) * GetIterationTPlanetDirectVisibility();"
        end_block = end_block[:m.start()] + light_replacement + end_block[m.end():]

    # No naked assignment may remain at global scope in this include's End
    # branch. Check specifically the injected identifiers, not unrelated
    # declarations from the shader's existing shared library.
    forbidden_assignment = re.search(
        r"(?m)^\s*(?:endLightColor|ambientColor|lightColor)\s*(?:\*=|=)", end_block
    )
    if forbidden_assignment:
        raise RuntimeError("lightAndAmbientColors.glsl: global-scope assignment remains in the End branch")

    text = text[:end_start] + end_block + text[end_stop:]
    write_text(p, text)


def cleanup_legacy_end_menus(text: str) -> str:
    """Remove retired Complementary End star/nebula menu controls from screens/sliders."""
    dead_screens = {"END_STAR", "STAR_COLORS_END", "END_NEBULA_SETTINGS"}
    dead_tokens = {
        "END_STARS", "END_STAR_BRIGHTNESS", "END_STAR_SIZE", "STAR_ROUNDNESS_END",
        "STAR_SOFTNESS_END", "END_STAR_AMOUNT", "STAR_LAYER_END", "END_TWINKLING_STARS",
        "END_STAR_HEMISPHERE", "STAR_COLOR_VARIATION_END",
        "STAR_COLOR_1_END_R", "STAR_COLOR_2_END_R", "STAR_COLOR_3_END_R",
        "STAR_COLOR_1_END_G", "STAR_COLOR_2_END_G", "STAR_COLOR_3_END_G",
        "STAR_COLOR_1_END_B", "STAR_COLOR_2_END_B", "STAR_COLOR_3_END_B",
        "END_NEBULA", "END_NEBULA_RESOLUTION", "END_NEBULA_DISTORTION_INTENSITY",
        "END_NEBULA_COVERAGE", "END_NEBULA_GRAININESS", "END_NEBULA_QUALITY",
        "END_NEBULA_HEMISPHERE", "END_NEBULA_COLOR_2_INTENSITY", "END_NEBULA_STAR_BRIGHTNESS",
        "END_NEBULA_ONLY_STARS", "END_NEBULA_ANIMATION_SPEED", "END_NEBULA_SEED",
    }
    dead_sliders = set(dead_tokens) - {"END_STARS"}
    lines = text.splitlines()
    out = []
    i = 0
    while i < len(lines):
        line = lines[i]
        screen_match = re.match(r"^\s*screen\.([A-Za-z0-9_]+)(?:\.[A-Za-z0-9_]+)?\s*=", line)
        if screen_match and screen_match.group(1) in dead_screens:
            i += 1
            continue

        if re.match(r"^\s*sliders\s*=", line):
            # Flatten this continued value into one property line, filter legacy slider IDs.
            first = line.rstrip()
            prefix, _, value = first.partition("=")
            if value.rstrip().endswith("\\"):
                value = value.rstrip()[:-1]
            value_parts = [value]
            i += 1
            while i < len(lines) and lines[i - 1].rstrip().endswith("\\"):
                part = lines[i].rstrip()
                continued = part.endswith("\\")
                if continued:
                    part = part[:-1]
                value_parts.append(part)
                i += 1
                if not continued:
                    break
            tokens = " ".join(value_parts).split()
            tokens = [token for token in tokens if token not in dead_sliders]
            out.append(prefix + "= " + " ".join(tokens))
            continue

        if line.lstrip().startswith("screen."):
            for token in dead_tokens:
                line = re.sub(rf"(?<![A-Za-z0-9_]){re.escape(token)}(?![A-Za-z0-9_])", "", line)
            # Remove empty placeholders left after deleting old nested menu references.
            line = re.sub(r"\s{2,}", " ", line)
            line = re.sub(r"=\s+", "=", line)
        out.append(line)
        i += 1
    return "\n".join(out).rstrip() + "\n"


def patch_properties(shaders: Path) -> None:
    p = shaders / "shaders.properties"
    text = read_text(p)
    euph_menu = (
        "            screen.END_SKY=<empty> <empty> [ITERATION_T] "
        "[END_BEAMS_SETTINGS] END_SKY_FOG_INFLUENCE EP_END_FLASH"
    )
    base_menu = (
        "    screen.END_SETTINGS=<empty> <empty> [ITERATION_T]"
    )
    if re.search(r"(?m)^\s*screen\.END_SKY\s*=", text):
        text = re.sub(r"(?m)^\s*screen\.END_SKY\s*=.*$", euph_menu, text, count=1)
    if re.search(r"(?m)^\s*screen\.END_SETTINGS\s*=", text):
        text = re.sub(r"(?m)^\s*screen\.END_SETTINGS\s*=.*$", base_menu, text, count=1)
    new_screen = (
        "        screen.ITERATION_T=<empty> <empty> END_T_SKY_BRIGHTNESS "
        "END_T_BLACK_HOLE END_T_BLACK_HOLE_INTENSITY END_T_BLACK_HOLE_ELEVATION END_T_DISC_TILT_LEFT_RIGHT END_T_DISC_TILT_UP_DOWN END_T_WARP_STRENGTH END_T_STARS "
        "END_T_STAR_INTENSITY END_T_PLANET END_T_PLANET_ELEVATION END_T_PLANET_ORBIT_PHASE END_T_PLANET_INTENSITY "
        "END_T_PLANET_CYCLE END_T_ANIMATION_SPEED END_T_SKY_ROTATION END_T_SKY_TILT "
        "END_T_LIGHT_BRIGHTNESS END_T_DIRECT_LIGHT_BRIGHTNESS END_T_LIGHT_NEUTRAL\n"
        "        screen.ITERATION_T.columns=2"
    )
    if "screen.ITERATION_T=" not in text:
        text += "\n\n# End Skybox controls\n" + new_screen + "\n"

    # Register shader slider controls. Euphoria splits this property over a
    # backslash-continued multi-line value, so append to the final continuation
    # line rather than placing tokens after the continuation backslash.
    slider_ids = [
        "END_T_SKY_BRIGHTNESS", "END_T_BLACK_HOLE_INTENSITY", "END_T_BLACK_HOLE_ELEVATION", "END_T_DISC_TILT_LEFT_RIGHT", "END_T_DISC_TILT_UP_DOWN", "END_T_WARP_STRENGTH",
        "END_T_STAR_INTENSITY", "END_T_PLANET_INTENSITY", "END_T_PLANET_ELEVATION", "END_T_PLANET_ORBIT_PHASE",
        "END_T_PLANET_CYCLE", "END_T_ANIMATION_SPEED", "END_T_SKY_ROTATION", "END_T_SKY_TILT",
        "END_T_LIGHT_BRIGHTNESS", "END_T_DIRECT_LIGHT_BRIGHTNESS", "END_T_LIGHT_NEUTRAL",
    ]
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if re.match(r"^\s*sliders\s*=", line):
            j = i
            while lines[j].rstrip().endswith("\\") and j + 1 < len(lines):
                j += 1
            existing = lines[j].split()
            missing_ids = [sid for sid in slider_ids if sid not in existing]
            if missing_ids:
                lines[j] = lines[j].rstrip() + " " + " ".join(missing_ids)
            break
    else:
        lines.append("sliders=" + " ".join(slider_ids))
    text = "\n".join(lines) + "\n"
    text = cleanup_legacy_end_menus(text)

    # Iris normally culls shadow casters using a frustum derived from the main
    # camera. Iteration T uses a custom End shadow-camera direction, so the
    # culler can reject blocks/entities behind the player even when they project
    # into the custom End shadow map. Iris evaluates shaders.properties
    # pack-wide (not per dimension), so this must be a global shadow-pass setting.
    reversed_pattern = re.compile(r"(?m)^[ \t]*shadow\.culling\s*=\s*reversed[ \t]*\r?\n")
    reversed_matches = list(reversed_pattern.finditer(text))
    if len(reversed_matches) != 1:
        raise RuntimeError(f"shaders.properties: expected one reversed shadow-culling setting, found {len(reversed_matches)}")
    m = reversed_matches[0]
    text = text[:m.start()] + text[m.end():]

    global_shadow_override = (
        "\n\n# End Skybox integration: full shadow-caster coverage for the custom End light direction.\n"
        "# shaders.properties is pack-wide, so this disables shadow-pass frustum culling\n"
        "# in all dimensions; ordinary camera frustum culling remains enabled.\n"
        "shadow.culling = false\n"
    )
    if "End Skybox integration: full shadow-caster coverage" not in text:
        text = text.rstrip() + global_shadow_override
    write_text(p, text)


def patch_default_ender_beams(shaders: Path) -> None:
    """Disable Complementary/Euphoria Ender beams in the default shader profile."""
    beam_settings = shaders / "lib/shaderSettings/endBeams.glsl"
    if beam_settings.is_file():
        text = read_text(beam_settings)
        text, count = re.subn(r"(?m)^(\s*)#define\s+END_BEAMS\s*$",
                              r"\1//#define END_BEAMS // default off for the End skybox integration",
                              text, count=1)
        if count == 0 and re.search(r"(?m)^\s*#define\s+END_BEAMS\b", text):
            raise RuntimeError("Could not disable the Euphoria END_BEAMS default")
        write_text(beam_settings, text)

    common_path = shaders / "lib/common.glsl"
    common_text = read_text(common_path)
    common_text, count = re.subn(r"(?m)^(\s*#define\s+END_BEAM_INTENSITY\s+)[0-9]+(?:\.[0-9]+)?",
                                 r"\g<1>0.00", common_text, count=1)
    if count == 0:
        raise RuntimeError("Could not set Complementary END_BEAM_INTENSITY default to zero")
    write_text(common_path, common_text)


def patch_languages(shaders: Path) -> None:
    """Install End Skybox labels and plain-language tooltips in every language file."""
    lang_dir = shaders / "lang"
    if not lang_dir.is_dir():
        return

    entries = []
    for line in LANG.strip().splitlines():
        line = line.rstrip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        entries.append(line)

    for path in lang_dir.glob("*.lang"):
        text = read_text(path)
        # Planet Size was removed because the control did not produce a useful change.
        text = re.sub(r"(?m)^option\.END_T_PLANET_SIZE(?:\.comment)?=.*\n?", "", text)
        text = re.sub(r"(?m)^value\.END_T_PLANET_SIZE\.[^=]+=.*\n?", "", text)

        for entry in entries:
            key = entry.split("=", 1)[0]
            pattern = re.compile(rf"(?m)^{re.escape(key)}=.*$")
            if pattern.search(text):
                text = pattern.sub(lambda _match, value=entry: value, text, count=1)
            else:
                if text and not text.endswith("\n"):
                    text += "\n"
                text += entry + "\n"

        write_text(path, text)


def validate_preprocessor_balance(text: str, path: str) -> None:
    stack = []
    for lineno, line in enumerate(text.splitlines(), 1):
        s = line.lstrip()
        if re.match(r"#\s*(if|ifdef|ifndef)\b", s):
            stack.append((lineno, s))
        elif re.match(r"#\s*endif\b", s):
            if not stack:
                raise RuntimeError(f"{path}:{lineno}: orphan #endif")
            stack.pop()
    if stack:
        line, directive = stack[-1]
        raise RuntimeError(f"{path}:{line}: unclosed preprocessor directive {directive}")


def audit_pack(pack_root: Path) -> None:
    shaders = pack_root / "shaders"
    module = shaders / "lib/atmospherics/iterationTEndSky.glsl"
    for rel in [
        "program/gbuffers_skybasic.glsl", "program/gbuffers_skytextured.glsl",
        "program/deferred1.glsl", "lib/materials/materialMethods/reflectionBackground.glsl",
    ]:
        p = shaders / rel
        text = read_text(p)
        validate_preprocessor_balance(text, rel)
        if 'iterationTEndSky.glsl' not in text:
            raise RuntimeError(f"{rel}: missing End-sky module include")
    modtext = read_text(module)
    validate_preprocessor_balance(modtext, "iterationTEndSky.glsl")
    required = [
        "const vec3 IT_WORLD_SHADOW_VECTOR = vec3(-0.85649968, -0.27635565, 0.43593102);",
        "IT_AdjustDirectionElevation(IT_WORLD_SUN_VECTOR, float(END_T_BLACK_HOLE_ELEVATION))",
        "IT_GetSkyAnchoredDiscRotation(lightDir)",
        "END_T_DISC_TILT_LEFT_RIGHT",
        "END_T_DISC_TILT_UP_DOWN",
        "vec3 blackHoleSkyDirection = normalize(lightDir)",
        "vec3 worldUpReference = vec3(0.0, 1.0, 0.0)",
        "vec3 skyRight = cross(worldUpReference, blackHoleSkyDirection)",
        "radians(-55.0 + float(END_T_DISC_TILT_UP_DOWN))",
        "float angleX = -1.67079633 - radians(float(END_T_PLANET_ELEVATION));",
        "float ringAngle = 0.0007084543;",
        "0.282 + float(END_T_PLANET_ORBIT_PHASE) / 360.0",
        "* 8.5 * (END_T_SKY_BRIGHTNESS * 0.01)",
        "IT_BlackHole_AccretionDisc_Stars",
        "IT_PlanetEnd2", "IT_PlanetEnd2(result, vec3(0.0), rayDir, lightDir, END_T_PLANET_INTENSITY * 0.01)",
        "float planetLightVisibility = 1.0 - planetOccultation", "topAtmoMie *= mix(0.04, 1.0, planetLightVisibility)",
        "ring *= mix(0.04, 1.0, planetLightVisibility)", "vec3 origin = ringOrigin + surfacePos / Rground;",
        "#ifndef ITERATION_T_END_SKY_MODULE", "#endif // ITERATION_T_END_SKY_MODULE",
        "color *= mix(1.0, transmittance, planetIntensity)", "IT_CalculateStars", "IT_CalculateCloudFBM",
        "IT_RaySphereIntersection", "IT_RayPlaneIntersection", "IT_Blackbody",
        "IT_GetEndSkyGamma", "IT_GetEndSkyReflectionGamma",
        "vec3 IT_GetEndSkyLightTint()", "result *= IT_GetEndSkyLightTint();",
        "float chromaBoost = 2.0;", "vec3 skyTintChroma = skyTint - vec3(skyTintLuma);",
        "#ifdef END_SKY_FOG_INFLUENCE", "END_T_LIGHT_NEUTRAL * 0.01",
    ]
    missing = [token for token in required if token not in modtext]
    if missing:
        raise RuntimeError("Original End-sky source functions missing from integration: " + ", ".join(missing))
    if modtext.count("result *= IT_GetEndSkyLightTint();") != 1:
        raise RuntimeError("End-sky elements are not receiving one shared End-light colour grade")
    if modtext.count("float IT_timeFactor =") != 1 or "IT_planetShadow" in modtext:
        raise RuntimeError("End-sky animation globals or old time-window planet-shadow mask remain")
    if "vec3 lightDir = IT_AdjustDirectionElevation(IT_WORLD_SUN_VECTOR, float(END_T_BLACK_HOLE_ELEVATION));" not in modtext:
        raise RuntimeError("End-sky light direction is not using the adjustable original-axis elevation")
    # Verify the planet is composited in-place and its fixed light direction is aligned.
    if "vec3 planetRadiance" in modtext:
        raise RuntimeError("The planet is still rendered through a transparent temporary buffer")
    if modtext.count("mat3 rotation = IT_GetSkyAnchoredDiscRotation(lightDir);") != 1:
        raise RuntimeError("The active black-hole raymarch must use the world-space sky-anchored disc transform")
    if re.search(r"\bgbufferModelViewInverse\b", re.sub(r"//[^\n]*", "", modtext)):
        raise RuntimeError("Disc orientation must not depend on the active camera matrix")
    common = read_text(shaders / "lib/common.glsl")
    if ("float angleX = -1.67079633 - radians(float(END_T_PLANET_ELEVATION));" not in modtext
            or "eye.y += 15e6;" not in modtext):
        raise RuntimeError("Fixed planet orbit plane or original observer offset is missing")
    if "0.282 + float(END_T_PLANET_ORBIT_PHASE) / 360.0" not in modtext:
        raise RuntimeError("Planet orbit phase no longer defaults to the original source phase")
    if "float ringAngle = 0.0007084543;" not in modtext:
        raise RuntimeError("Ring side must remain fixed with a constant signed near-edge-on lean")
    if "sin(IT_timeFactor + 3.0)" in modtext or "sin(IT_timeFactor + 4.6)" in modtext:
        raise RuntimeError("Planet vertical bob or ring side-flip animation is still present")
    if "vec3 ringOrigin = vec3(0.0, cos(ringAngle), sin(ringAngle)) * (eye.y / Rground);" not in modtext:
        raise RuntimeError("Original source observer-to-ring-plane relationship was not restored")
    if "ringRoataionMatrix = mat3(1.0, 0.0, 0.0" not in modtext:
        raise RuntimeError("Original source ring rotation matrix was not restored")
    if "ringRoataionMatrix * eye / Rground" in modtext or "cos(radians(75.0))" in modtext:
        raise RuntimeError("A custom ring tilt is still moving the viewpoint away from the original ring plane")
    if ("float ringRayDistance = -ringOrigin.z / rayDirRing.z;" not in modtext
            or "ringRayDistance * Rground > groundIntersection.x + 1.0" not in modtext
            or "bool planetBlocksRing" not in modtext):
        raise RuntimeError("Ring rendering is missing the front/back planet-depth occlusion test")
    if "#define END_T_DISC_TILT_UP_DOWN 20" not in common:
        raise RuntimeError("common.glsl: accretion disc Up/Down default must be +20")
    if "radians(-55.0 + float(END_T_DISC_TILT_UP_DOWN))" not in modtext:
        raise RuntimeError("Zero Up/Down dial must include the requested +30-degree base correction")
    if "float angleX = -1.67079633 - radians(float(END_T_PLANET_ELEVATION));" not in modtext:
        raise RuntimeError("Planet does not use the fixed, non-bobbing orbit-plane angle")
    common_functions = read_text(shaders / "lib/util/commonFunctions.glsl")
    space_conversion = read_text(shaders / "lib/util/spaceConversion.glsl")
    shadow_program = read_text(shaders / "program/shadow.glsl")
    if "GetIterationTEndShadowModelView()" not in space_conversion or "GetIterationTEndShadowModelView() * position" not in shadow_program:
        raise RuntimeError("End shadow map writer/reader are not using the same black-hole-aligned matrix")
    if "GetIterationTEndLightDirection()" not in space_conversion:
        raise RuntimeError("End shadow camera is not using the elevated sky light direction")
    if "mat4 endShadowModelView = GetIterationTEndShadowModelView();" not in space_conversion:
        raise RuntimeError("End shadow sampling is not using the black-hole-aligned matrix")
    if "GetIterationTEndLightDirection()" not in common_functions or "GetIterationTPlanetDirectVisibility()" not in common_functions:
        raise RuntimeError("commonFunctions.glsl: elevated End light direction or planet occultation helper is missing")
    if common_functions.count("#define GetSunVector() normalize(mat3(gbufferModelView) * GetIterationTEndLightDirection())") < 1:
        raise RuntimeError("commonFunctions.glsl: End GetSunVector is not using the shared sky direction")
    if "vec3(-0.85649968, -0.27635565, 0.43593102)" not in common_functions:
        raise RuntimeError("commonFunctions.glsl: End light direction does not match the source skybox geometry")
    if "GetIterationTEndSceneRotation() * GetIterationTEndBlackHoleDirectionLocal()" not in common_functions:
        raise RuntimeError("commonFunctions.glsl: light and shadow direction are not using the adjustable black-hole elevation")
    if "asin(clamp(originalDirection.y, -1.0, 1.0)) + radians(float(END_T_BLACK_HOLE_ELEVATION))" not in common_functions:
        raise RuntimeError("commonFunctions.glsl: black-hole elevation control is not applied in angle space")
    if "GetIterationTEndSceneRotation() * planetCentreLocal" not in common_functions:
        raise RuntimeError("commonFunctions.glsl: planet eclipse direction is not transformed with the visible sky")
    if "float angleX = -1.67079633 - radians(float(END_T_PLANET_ELEVATION));" not in common_functions:
        raise RuntimeError("commonFunctions.glsl: planet eclipse helper is not using the fixed orbit-plane angle")
    if "sin(planetTime + 3.0)" in common_functions:
        raise RuntimeError("commonFunctions.glsl: animated vertical bob remains in planet eclipse helper")
    lighting = read_text(shaders / "lib/colors/lightAndAmbientColors.glsl")
    if "endLightNeutral" not in lighting or "END_T_LIGHT_BRIGHTNESS" not in lighting or "END_T_DIRECT_LIGHT_BRIGHTNESS" not in lighting or "GetIterationTPlanetDirectVisibility()" not in lighting:
        raise RuntimeError("lightAndAmbientColors.glsl: bright, eclipsed direct End lighting not applied")
    if not re.search(r"(?m)^\s*vec3\s+lightColor\s*=.*END_T_DIRECT_LIGHT_BRIGHTNESS.*GetIterationTPlanetDirectVisibility\(\)", lighting):
        raise RuntimeError("lightAndAmbientColors.glsl: direct light is not multiplied by brightness and planet occultation")
    end_branch_start = lighting.find("#elif defined END")
    end_branch_stop = lighting.find("#endif", end_branch_start)
    end_branch = lighting[end_branch_start:end_branch_stop]
    if re.search(r"(?m)^\s*(?:endLightColor|ambientColor|lightColor)\s*(?:\*=|=)", end_branch):
        raise RuntimeError("lightAndAmbientColors.glsl: invalid global-scope assignment remains in the End branch")
    for declaration in ["vec3 endLightColor =", "vec3 ambientColor =", "vec3 lightColor ="]:
        if declaration not in end_branch:
            raise RuntimeError(f"lightAndAmbientColors.glsl: missing End lighting declaration: {declaration}")
    common = read_text(shaders / "lib/common.glsl")
    if "END_T_PLANET_SIZE" in common or "END_T_PLANET_SIZE" in modtext:
        raise RuntimeError("Planet Size control must be removed; original fixed Iteration T planet radius is used")
    if "#define END_T_LIGHT_BRIGHTNESS 150" not in common or "#define END_T_DIRECT_LIGHT_BRIGHTNESS 350" not in common or "#define END_T_LIGHT_NEUTRAL 100" not in common:
        raise RuntimeError("common.glsl: End lighting controls missing")
    expected_defaults = {
        "END_T_BLACK_HOLE_ELEVATION": 30,
        "END_T_DISC_TILT_LEFT_RIGHT": -15,
        "END_T_DISC_TILT_UP_DOWN": 20,
        "END_T_PLANET_ELEVATION": 0,
        "END_T_PLANET_ORBIT_PHASE": 130,
        "END_T_SKY_ROTATION": 0,
    }
    for setting, expected in expected_defaults.items():
        if not re.search(rf"(?m)^\s*#define {setting} {expected}\b", common):
            raise RuntimeError(f"common.glsl: expected default missing for {setting}={expected}")
    for setting, expected in {
        "END_T_PLANET_CYCLE": "20.0",
        "END_T_DIRECT_LIGHT_BRIGHTNESS": "350",
        "SHADOW_SMOOTHING": "2",
    }.items():
        if not re.search(rf"(?m)^\s*#define {setting} {re.escape(expected)}\b", common):
            raise RuntimeError(f"common.glsl: requested default missing for {setting}={expected}")
    if not re.search(r"(?m)^\s*#define PIXELATED_SHADOWS\b", common):
        raise RuntimeError("common.glsl: PIXELATED_SHADOWS must be enabled by default")
    if (shaders / "lib/shaderSettings/composite1.glsl").is_file():
        for rel in ["lib/shaderSettings/composite1.glsl", "lib/shaderSettings/deferred1.glsl"]:
            text = read_text(shaders / rel)
            if not re.search(r"(?m)^\s*#define EP_END_FLASH 1\b", text):
                raise RuntimeError(f"{rel}: EP_END_FLASH must default to 1")
        night = read_text(shaders / "lib/shaderSettings/composite5.glsl")
        if not re.search(r"(?m)^\s*#define NIGHT_DESATURATION_END 300\b", night):
            raise RuntimeError("composite5.glsl: NIGHT_DESATURATION_END must default to 300")
        if not re.search(r"(?m)^\s*#define DRAGON_DEATH_EFFECT 2\b", common):
            raise RuntimeError("common.glsl: DRAGON_DEATH_EFFECT must default to 2")
        if not re.search(r"(?m)^\s*#define END_CRYSTAL_VORTEX 3\b", common):
            raise RuntimeError("common.glsl: END_CRYSTAL_VORTEX must default to 3")
        if not re.search(r"(?m)^\s*#define PIXELATED_WATER_REFLECTIONS\b", common):
            raise RuntimeError("common.glsl: PIXELATED_WATER_REFLECTIONS must be enabled by default")
    if "END_T_DISC_TILT " in common:
        raise RuntimeError("common.glsl: obsolete ambiguous Accretion Disc Tilt setting remains")

    if "END_T_PLANET_TILT_UP_DOWN" in common or "END_T_PLANET_TILT_LEFT_RIGHT" in common or "END_T_PLANET_TILT_UP_DOWN" in modtext or "END_T_PLANET_TILT_LEFT_RIGHT" in modtext:
        raise RuntimeError("Planet axial tilt options must be removed from the shader source")
    if "END_T_PLANET_CYCLE >= 250.0" not in modtext or "END_T_PLANET_CYCLE >= 250.0" not in common_functions:
        raise RuntimeError("Planet Cycle value 250 must pause the planet orbit and eclipse calculation")
    if "radians(130.0 + float(END_T_SKY_ROTATION))" not in modtext or "radians(130.0 + float(END_T_SKY_ROTATION))" not in common_functions:
        raise RuntimeError("Zero Sky Rotation must preserve the configured 130-degree base orientation")
    beam_file = shaders / "lib/shaderSettings/endBeams.glsl"
    if beam_file.is_file() and re.search(r"(?m)^\s*#define\s+END_BEAMS\s*$", read_text(beam_file)):
        raise RuntimeError("Euphoria Ender Beams are not disabled by default")
    if not re.search(r"(?m)^\s*#define END_BEAM_INTENSITY 0\.00\b", common):
        raise RuntimeError("Complementary End Beam Intensity must default to zero")
    properties = read_text(shaders / "shaders.properties")
    if "screen.ITERATION_T=<empty> <empty>" not in properties:
        raise RuntimeError("shaders.properties: End Skybox settings screen is missing")
    english_lang = shaders / "lang/en_US.lang"
    if not english_lang.is_file():
        raise RuntimeError("en_US.lang: English language file is missing")
    english_text = read_text(english_lang)
    if "screen.ITERATION_T=End Skybox" not in english_text:
        raise RuntimeError("en_US.lang: End Skybox settings screen label is missing")
    if "option.END_T_PLANET_CYCLE=Planet Cycle (minutes)" not in english_text:
        raise RuntimeError("en_US.lang: Planet Cycle must be labelled in minutes")
    if "Default: 20 minutes" not in english_text:
        raise RuntimeError("en_US.lang: Planet Cycle tooltip must state its 20-minute default")
    for line in LANG.splitlines():
        if not line.startswith("option.") or ".comment=" in line or "=" not in line:
            continue
        option_key = line.split("=", 1)[0]
        tooltip_key = option_key + ".comment"
        tooltip_match = re.search(rf"(?m)^{re.escape(tooltip_key)}=(.*)$", english_text)
        if not tooltip_match or "Default:" not in tooltip_match.group(1):
            raise RuntimeError(f"en_US.lang: setting description missing a default: {option_key}")
    if not re.search(r"(?m)^shadow\.culling\s*=\s*false\s*$", properties):
        raise RuntimeError("shaders.properties: shadow-pass frustum culling is not disabled for off-screen casters")
    if re.search(r"(?m)^\s*shadow\.culling\s*=\s*reversed\s*$", properties):
        raise RuntimeError("shaders.properties: reversed shadow culling still overrides the full-caster setting")
    if "End Skybox integration: full shadow-caster coverage" not in properties:
        raise RuntimeError("shaders.properties: missing explanation for the pack-wide shadow-culling setting")
    for setting in ["END_T_BLACK_HOLE_ELEVATION", "END_T_DISC_TILT_LEFT_RIGHT", "END_T_DISC_TILT_UP_DOWN", "END_T_PLANET_ELEVATION", "END_T_PLANET_ORBIT_PHASE", "END_T_SKY_ROTATION"]:
        if setting not in properties:
            raise RuntimeError(f"shaders.properties: missing in-game control {setting}")
    for setting in ["END_T_SKY_BRIGHTNESS", "END_T_BLACK_HOLE", "END_T_STARS", "END_T_PLANET", "END_T_LIGHT_BRIGHTNESS", "END_T_DIRECT_LIGHT_BRIGHTNESS", "END_T_LIGHT_NEUTRAL"]:
        if setting not in properties:
            raise RuntimeError(f"shaders.properties: missing settings menu item {setting}")
    if "END_T_DISC_TILT " in properties:
        raise RuntimeError("shaders.properties: obsolete Accretion Disc Tilt setting remains")
    if "END_T_PLANET_SIZE" in properties:
        raise RuntimeError("shaders.properties: removed Planet Size control remains")
    for lang_file in (shaders / "lang").glob("*.lang"):
        if "END_T_PLANET_SIZE" in read_text(lang_file):
            raise RuntimeError(f"{lang_file.name}: removed Planet Size translation remains")
    for stale in [r"(?m)^\s*screen\.END_STAR(?:\.|=)", r"(?m)^\s*screen\.STAR_COLORS_END(?:\.|=)", r"(?m)^\s*screen\.END_NEBULA_SETTINGS(?:\.|=)"]:
        if re.search(stale, properties):
            raise RuntimeError(f"shaders.properties: retired End submenu remains: {stale}")
    screen_lines = "\n".join(line for line in properties.splitlines() if line.lstrip().startswith("screen."))
    for stale in ["END_STARS", "END_STAR_BRIGHTNESS", "END_STAR_SIZE", "END_STAR_AMOUNT", "END_TWINKLING_STARS", "END_NEBULA", "END_NEBULA_RESOLUTION", "STAR_COLOR_1_END_R"]:
        if re.search(rf"(?<![A-Za-z0-9_]){stale}(?![A-Za-z0-9_])", screen_lines):
            raise RuntimeError(f"shaders.properties: retired End screen control remains: {stale}")
    if re.search(r"\\\s+END_T_", properties):
        raise RuntimeError("shaders.properties: End Skybox slider values were appended after a continuation slash")

    # Confirm that every sky-rendering path uses the complete Iteration T sky colour.
    checks = {
        "program/gbuffers_skybasic.glsl": "IT_GetEndSkyGamma(endWorldRay)",
        "program/gbuffers_skytextured.glsl": "IT_GetEndSkyGamma(endWorldRay)",
        "program/deferred1.glsl": "IT_GetEndSkyGamma(endWorldRay)",
        "lib/materials/materialMethods/reflectionBackground.glsl": "IT_GetEndSkyReflectionGamma(endWorldReflectionRay)",
    }
    for rel, token in checks.items():
        if rel.endswith("reflectionBackground.glsl"):
            reflection_text = read_text(shaders / rel)
            if token not in reflection_text or "#ifdef VOXY_TRANSLUCENT" not in reflection_text or "vec3 skyReflection = endSkyColor * skyLightFactor;" not in reflection_text:
                raise RuntimeError("reflectionBackground.glsl: Voxy-safe reflection fallback or full reflection path missing")
            if '#if defined END && (defined COMPOSITE || defined GBUFFERS_WATER)' not in reflection_text:
                raise RuntimeError("reflectionBackground.glsl: End volumetric include is not excluded from Voxy")
            if '#if defined COMPOSITE || defined GBUFFERS_WATER\n            #ifdef COMPOSITE' not in reflection_text:
                raise RuntimeError("reflectionBackground.glsl: End volumetric call is not restricted to Iris composite/water passes")
        elif token not in read_text(shaders / rel):
            raise RuntimeError(f"{rel}: expected End-sky render call is missing")

    deferred = read_text(shaders / "program/deferred1.glsl")
    reflection = read_text(shaders / "lib/materials/materialMethods/reflectionBackground.glsl")
    if "volumetricEffect.rgb" in reflection:
        volumetric_decl = reflection.find("vec4 volumetricEffect = GetVolumetricLight(")
        volumetric_use = reflection.find("skyReflection += volumetricEffect.rgb")
        if volumetric_decl < 0 or volumetric_use < volumetric_decl:
            raise RuntimeError("reflectionBackground.glsl: volumetricEffect is referenced before its declaration")
    for rel, text in [("deferred1.glsl", deferred), ("reflectionBackground.glsl", reflection)]:
        for obsolete in ["GetEnderStars(", "GetEnderNebula(", "GetBlackHole(", "GetBlackHoleLensedDirection("]:
            if obsolete in text:
                raise RuntimeError(f"{rel}: old End sky function still active: {obsolete}")

    # All files where the module is imported are shared vertex/fragment sources;
    # the include must be protected by FRAGMENT_SHADER.
    reflection_text = read_text(shaders / "lib/materials/materialMethods/reflectionBackground.glsl")
    if '#if defined END && defined FRAGMENT_SHADER && !defined VOXY_TRANSLUCENT\n    #include "/lib/atmospherics/iterationTEndSky.glsl"\n#endif' not in reflection_text:
        raise RuntimeError("reflectionBackground.glsl: Voxy-safe guarded End-sky include missing")
    voxy_branch = reflection_text.split("#ifdef VOXY_TRANSLUCENT", 1)[1].split("#else", 1)[0]
    if "GetVolumetricLight(" in voxy_branch or "texCoord" in voxy_branch:
        raise RuntimeError("reflectionBackground.glsl: Voxy fallback still depends on unavailable texCoord/volumetrics")
    if "|| defined VOXY_TRANSLUCENT" in reflection_text:
        raise RuntimeError("reflectionBackground.glsl: Voxy is still included in the End volumetric pass")
    for rel in ["program/gbuffers_skybasic.glsl", "program/gbuffers_skytextured.glsl", "program/deferred1.glsl"]:
        content = read_text(shaders / rel)
        if '#if defined END && defined FRAGMENT_SHADER\n    #include "/lib/atmospherics/iterationTEndSky.glsl"\n#endif' not in content:
            raise RuntimeError(f"{rel}: End-sky module include is not fragment guarded")
    for p in shaders.rglob("*.glsl"):
        txt = read_text(p)
        validate_preprocessor_balance(txt, str(p.relative_to(shaders)))


def patch_default_settings(shaders: Path) -> None:
    """Apply the default option values as first-load shader defaults."""
    def replace_define(path: Path, name: str, value: str, required: bool = True) -> None:
        text = read_text(path)
        pattern = re.compile(rf"(?m)^([ \t]*#define[ \t]+{re.escape(name)}[ \t]+)([^\r\n]+)")
        match = pattern.search(text)
        if not match:
            if required:
                raise RuntimeError(f"{path.name}: missing setting {name}")
            return
        tail = re.sub(r"^\S+", value, match.group(2), count=1)
        text = text[:match.start(2)] + tail + text[match.end(2):]
        write_text(path, text)

    def enable_toggle(path: Path, name: str, required: bool = False) -> None:
        text = read_text(path)
        commented = re.compile(rf"(?m)^([ \t]*)//([ \t]*#define[ \t]+{re.escape(name)}\b[^\r\n]*)")
        if commented.search(text):
            text = commented.sub(lambda m: m.group(1) + m.group(2), text, count=1)
            write_text(path, text)
            return
        active = re.compile(rf"(?m)^[ \t]*#define[ \t]+{re.escape(name)}\b")
        if active.search(text):
            return
        if required:
            raise RuntimeError(f"{path.name}: missing toggle {name}")

    common = shaders / "lib/common.glsl"
    for name, value in {
        "END_T_DIRECT_LIGHT_BRIGHTNESS": "350",
        "END_T_PLANET_CYCLE": "20.0",
        "END_T_PLANET_ORBIT_PHASE": "130",
        "SHADOW_SMOOTHING": "2",
        "DRAGON_DEATH_EFFECT": "2",
        "END_CRYSTAL_VORTEX": "3",
    }.items():
        replace_define(common, name, value, required=name in {
            "END_T_DIRECT_LIGHT_BRIGHTNESS", "END_T_PLANET_CYCLE",
            "END_T_PLANET_ORBIT_PHASE", "SHADOW_SMOOTHING"
        })
    enable_toggle(common, "PIXELATED_SHADOWS", required=True)
    enable_toggle(common, "PIXELATED_WATER_REFLECTIONS", required=False)

    for rel in ["lib/shaderSettings/composite1.glsl", "lib/shaderSettings/deferred1.glsl"]:
        path = shaders / rel
        if path.is_file():
            replace_define(path, "EP_END_FLASH", "1", required=False)
    night = shaders / "lib/shaderSettings/composite5.glsl"
    if night.is_file():
        replace_define(night, "NIGHT_DESATURATION_END", "300", required=False)

    properties = shaders / "shaders.properties"
    if properties.is_file():
        text = read_text(properties)
        profile = re.compile(r"(?m)^([ \t]*profile2\.DEFAULT[ \t]*=[ \t]*)([^\r\n]*)")
        match = profile.search(text)
        if match:
            tokens = match.group(2).split()
            desired = {
                "END_CRYSTAL_VORTEX": "END_CRYSTAL_VORTEX=3",
                "DRAGON_DEATH_EFFECT": "DRAGON_DEATH_EFFECT=2",
                "END_T_DIRECT_LIGHT_BRIGHTNESS": "END_T_DIRECT_LIGHT_BRIGHTNESS=350",
                "END_T_PLANET_CYCLE": "END_T_PLANET_CYCLE=20.0",
                "END_T_PLANET_ORBIT_PHASE": "END_T_PLANET_ORBIT_PHASE=130",
                "EP_END_FLASH": "EP_END_FLASH=1",
                "NIGHT_DESATURATION_END": "NIGHT_DESATURATION_END=300",
                "PIXELATED_SHADOWS": "PIXELATED_SHADOWS",
                "PIXELATED_WATER_REFLECTIONS": "PIXELATED_WATER_REFLECTIONS",
                "SHADOW_SMOOTHING": "SHADOW_SMOOTHING=2",
            }
            for key, replacement in desired.items():
                for i, token in enumerate(tokens):
                    if token.lstrip("!").split("=", 1)[0] == key:
                        tokens[i] = replacement
                        break
                else:
                    tokens.append(replacement)
            text = text[:match.start()] + match.group(1) + " ".join(tokens) + text[match.end():]
            write_text(properties, text)


def patch_pack_with_module(pack_root: Path, module_text: str) -> None:
    shaders = pack_root / "shaders"
    required = [
        shaders / "lib/common.glsl", shaders / "program/deferred1.glsl",
        shaders / "program/gbuffers_skybasic.glsl", shaders / "program/gbuffers_skytextured.glsl",
        shaders / "lib/materials/materialMethods/reflectionBackground.glsl", shaders / "shaders.properties",
    ]
    missing = [str(p.relative_to(pack_root)) for p in required if not p.is_file()]
    if missing:
        raise RuntimeError("Not a supported Complementary/Euphoria pack; missing " + ", ".join(missing))
    if (shaders / MODULE_REL.relative_to("shaders")).exists():
        raise RuntimeError("This shader pack already contains the Iteration T End skybox integration. Select an unmodified source pack instead.")

    module_path = shaders / MODULE_REL.relative_to("shaders")
    module_path.parent.mkdir(parents=True, exist_ok=True)
    write_text(module_path, module_text)

    patch_common(shaders)
    patch_default_ender_beams(shaders)
    patch_skybasic(shaders)
    patch_skytextured(shaders)
    patch_deferred(shaders)
    patch_reflection(shaders)
    patch_end_light_direction(shaders)
    patch_end_shadow_matrices(shaders)
    patch_end_lighting(shaders)
    patch_properties(shaders)
    patch_default_settings(shaders)
    patch_languages(shaders)
    audit_pack(pack_root)


def main() -> int:
    if sys.version_info < (3, 11):
        print("The Complementary End Skybox Patcher requires Python 3.11 or newer.", file=sys.stderr)
        return 2
    parser = argparse.ArgumentParser(
        prog="patch_complementary.py",
        description="Add the Iteration T End skybox to a new copy of a compatible Complementary shader pack.",
        epilog=(
            "Supported source formats: extracted shader-pack folders and ZIP archives. "
            "The source pack is never modified."
        ),
    )
    parser.add_argument("input", type=Path, help="Original Complementary or Euphoria-patched shader-pack folder or ZIP")
    parser.add_argument("output", type=Path, help="Destination folder or ZIP for the patched pack")
    args = parser.parse_args()

    src = args.input.expanduser().resolve()
    out = args.output.expanduser().resolve()
    if not src.exists():
        parser.error(f"Input does not exist: {src}")
    if src == out:
        parser.error("Output must be different from input")
    if out.exists():
        parser.error(f"Output already exists: {out}")
    if not (src.is_dir() or (src.is_file() and src.suffix.lower() == ".zip")):
        parser.error("Input must be an extracted folder or a ZIP archive")

    module_path = HERE / "iteration_t_end_sky.glsl"
    if not module_path.is_file():
        parser.error(f"Bundled End-sky module (adapted from Iteration T) not found: {module_path}")
    module_text = read_text(module_path)

    with tempfile.TemporaryDirectory(prefix="iteration-t-") as tmp:
        temp = Path(tmp) / "pack"
        temp.mkdir()
        if src.is_dir():
            shutil.copytree(src, temp, dirs_exist_ok=True)
        else:
            safe_extract(src, temp)
        pack_root = find_pack_root(temp)
        patch_pack_with_module(pack_root, module_text)
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.suffix.lower() == ".zip":
            make_zip(pack_root, out)
        else:
            shutil.copytree(pack_root, out)

    print(f"Created patched shader pack: {out}")
    print("The original source pack was not modified.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
