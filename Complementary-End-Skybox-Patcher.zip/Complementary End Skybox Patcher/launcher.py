#!/usr/bin/env python3
"""Graphical launcher for the Complementary End Skybox Patcher."""
from __future__ import annotations

import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox

HERE = Path(__file__).resolve().parent
PATCHER = HERE / "patch_complementary.py"
MODULE = HERE / "iteration_t_end_sky.glsl"
MINIMUM_PYTHON = (3, 11)


def output_path(source: Path) -> Path:
    """Choose a non-overwriting output path beside the selected source."""
    if source.is_dir():
        base = source.parent / f"{source.name}-End-Skybox"
        suffix = ""
    else:
        base = source.parent / f"{source.stem}-End-Skybox"
        suffix = ".zip"

    candidate = Path(f"{base}{suffix}")
    index = 2
    while candidate.exists():
        candidate = Path(f"{base}-{index}{suffix}")
        index += 1
    return candidate


class ComplementaryEndSkyPatcher:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        root.title("Complementary End Skybox Patcher")
        root.geometry("600x390")
        root.minsize(560, 360)
        root.columnconfigure(0, weight=1)

        tk.Label(root, text="Complementary End Skybox Patcher", font=("Segoe UI", 21, "bold")).grid(
            row=0, column=0, padx=26, pady=(24, 4), sticky="w"
        )
        tk.Label(
            root,
            text="Add the Iteration T End skybox to Complementary Reimagined.",
            font=("Segoe UI", 10),
        ).grid(row=1, column=0, padx=26, pady=(0, 18), sticky="w")

        instructions = (
            "Select an original, unmodified shader pack. Supported inputs are:\n\n"
            "• Complementary Reimagined as a ZIP file or extracted folder\n"
            "• Euphoria Patches applied to Complementary Reimagined, as an extracted folder\n\n"
            "A new copy is created beside the source. The selected source is never changed."
        )
        tk.Label(root, text=instructions, justify="left", anchor="w", wraplength=540).grid(
            row=2, column=0, padx=26, pady=(0, 20), sticky="ew"
        )

        buttons = tk.Frame(root)
        buttons.grid(row=3, column=0, padx=26, sticky="ew")
        buttons.columnconfigure(0, weight=1)
        buttons.columnconfigure(1, weight=1)
        self.folder_button = tk.Button(
            buttons, text="Select shader-pack folder…", height=2, command=self.choose_folder
        )
        self.folder_button.grid(row=0, column=0, padx=(0, 7), sticky="ew")
        self.zip_button = tk.Button(
            buttons, text="Select shader-pack ZIP…", height=2, command=self.choose_zip
        )
        self.zip_button.grid(row=0, column=1, padx=(7, 0), sticky="ew")

        self.status = tk.StringVar(value="Ready. Select an original compatible shader pack.")
        tk.Label(root, textvariable=self.status, anchor="w", fg="#424242", wraplength=540).grid(
            row=4, column=0, padx=26, pady=(20, 0), sticky="ew"
        )
        tk.Label(
            root,
            text="Requires Python 3.11 or newer. No additional Python packages are required.",
            anchor="w", fg="#666666", font=("Segoe UI", 9),
        ).grid(row=5, column=0, padx=26, pady=(10, 20), sticky="ew")

    def choose_folder(self) -> None:
        selected = filedialog.askdirectory(title="Select an original shader-pack folder")
        if selected:
            self.install(Path(selected))

    def choose_zip(self) -> None:
        selected = filedialog.askopenfilename(
            title="Select an original shader-pack ZIP",
            filetypes=[("Shader-pack ZIP files", "*.zip"), ("All files", "*.*")],
        )
        if selected:
            self.install(Path(selected))

    def set_busy(self, busy: bool) -> None:
        state = "disabled" if busy else "normal"
        self.folder_button.configure(state=state)
        self.zip_button.configure(state=state)
        self.root.update_idletasks()

    def install(self, source: Path) -> None:
        if not PATCHER.is_file() or not MODULE.is_file():
            messagebox.showerror(
                "Installation files missing",
                "Keep launcher.py, patch_complementary.py and iteration_t_end_sky.glsl together in the same folder.",
                parent=self.root,
            )
            return
        if not source.exists():
            messagebox.showerror("Source not found", "The selected path does not exist.", parent=self.root)
            return

        destination = output_path(source)
        self.set_busy(True)
        self.status.set("Adding the Iteration T End skybox and checking the new shader pack…")
        try:
            result = subprocess.run(
                [sys.executable, str(PATCHER), str(source), str(destination)],
                cwd=str(HERE), capture_output=True, text=True, check=False,
            )
        except OSError as exc:
            self.status.set("The patcher could not be started.")
            messagebox.showerror("Could not start patcher", str(exc), parent=self.root)
            return
        finally:
            self.set_busy(False)

        if result.returncode != 0:
            details = "\n".join(part for part in (result.stdout, result.stderr) if part).strip()
            self.status.set("Installation stopped. The source pack was not modified.")
            messagebox.showerror(
                "Installation failed",
                details or "The patcher stopped without returning additional details.",
                parent=self.root,
            )
            return

        self.status.set(f"Created: {destination.name}")
        messagebox.showinfo(
            "Shader pack created",
            "The patched shader pack was created successfully.\n\n"
            f"Location:\n{destination}\n\n"
            "The original shader pack was not modified. Select the new pack in Minecraft.",
            parent=self.root,
        )


def main() -> int:
    if sys.version_info < MINIMUM_PYTHON:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "Python version not supported",
            "The patcher requires Python 3.11 or newer. Install a current version from python.org.",
            parent=root,
        )
        root.destroy()
        return 1

    root = tk.Tk()
    ComplementaryEndSkyPatcher(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
