@echo off
setlocal
cd /d "%~dp0"
py -3 launcher.py
if errorlevel 1 (
    echo.
    echo If Python is not installed, follow the setup guide in README.md.
    pause
)
