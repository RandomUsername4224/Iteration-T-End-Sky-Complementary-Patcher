#ifndef ITERATION_T_END_SKY_MODULE
#define ITERATION_T_END_SKY_MODULE

// Iteration T End-sky rendering module, adapted from the original EndSky.glsl source.
// Functions and ray-march are kept from the original source and namespaced (IT_).
// Integration adaptations: Euphoria uniforms, controls, coordinate wrapper and gamma output.

#define IT_PI 3.14159265359
#define IT_TAU 6.28318530718
#define IT_GOLDEN_RATIO 1.61803398875
#define IT_PLASTIC_RATIO 1.32471795724
#define IT_SATURATE(x) clamp((x), 0.0, 1.0)
#define IT_CURVE(x) ((x) * (x) * (3.0 - 2.0 * (x)))

// Implemented after the source rotation helpers below; used by both disc raymarches.
mat3 IT_GetSkyAnchoredDiscRotation(vec3 lightDir);

// Original Iteration T End axis from ShadowModelViewEnd.glsl.
// The original direction is about 16 degrees below the horizon; the in-game
// Black Hole Elevation control adds an offset without changing the default.
const vec3 IT_WORLD_SHADOW_VECTOR = vec3(-0.85649968, -0.27635565, 0.43593102);
const vec3 IT_WORLD_SUN_VECTOR = IT_WORLD_SHADOW_VECTOR;

float IT_planetPhaseOffset = 0.282 + float(END_T_PLANET_ORBIT_PHASE) / 360.0;
float IT_timeFactor = (END_T_PLANET_CYCLE >= 250.0)
    ? fract(IT_planetPhaseOffset) * IT_TAU
    : fract(frameTimeCounter * ((1.0 / 60.0) / max(END_T_PLANET_CYCLE, 1.0)) * (END_T_ANIMATION_SPEED * 0.01) + IT_planetPhaseOffset) * IT_TAU;


float IT_remapSaturate(float x, float e0, float e1) {
    return IT_SATURATE((x - e0) / (e1 - e0));
}

float IT_atan2(vec2 v) {
    return v.x == 0.0 ?
        (1.0 - step(abs(v.y), 0.0)) * sign(v.y) * 1.57079632679 :
        atan(v.y / v.x) + step(v.x, 0.0) * sign(v.y) * IT_PI;
}

vec3 IT_Blackbody(float temperature) {
    const mat2x4 splineX = mat2x4(-0.2661293e9, -0.2343589e6, 0.8776956e3, 0.179910,
                                  -3.0258469e9,  2.1070479e6, 0.2226347e3, 0.240390);
    const mat3x4 splineY = mat3x4(-1.1063814, -1.34811020, 2.18555832, -0.20219683,
                                  -0.9549476, -1.37418593, 2.09137015, -0.16748867,
                                   3.0817580, -5.87338670, 3.75112997, -0.37001483);

    float rt = 1.0 / temperature;
    float rt2 = rt * rt;
    vec4 coeffX = vec4(rt2 * rt, rt2, rt, 1.0);
    float x = dot(coeffX, temperature < 4000.0 ? splineX[0] : splineX[1]);
    float x2 = x * x;
    vec4 coeffY = vec4(x2 * x, x2, x, 1.0);
    float z = 1.0 / dot(coeffY, temperature < 2222.0 ? splineY[0] : temperature < 4000.0 ? splineY[1] : splineY[2]);
    vec3 xyz = vec3(x * z, 1.0, z);
    xyz.z -= xyz.x + 1.0;
    const mat3 xyzToSrgb = mat3(3.24097, -0.96924, 0.05563,
                                -1.53738, 1.87597, -0.20398,
                                -0.49861, 0.04156, 1.05697);
    return max(xyzToSrgb * xyz, vec3(0.0));
}

vec3 IT_RayPlaneIntersection(vec3 ori, vec3 dir, vec3 normal) {
    float rayPlaneAngle = dot(dir, normal);
    float planeRayDist = 1e8;
    vec3 intersectionPos = dir * planeRayDist;
    if (rayPlaneAngle > 0.0001 || rayPlaneAngle < -0.0001) {
        planeRayDist = dot(-ori, normal) / rayPlaneAngle;
        intersectionPos = ori + dir * planeRayDist;
    }
    return intersectionPos;
}

vec2 IT_RaySphereIntersection(vec3 ori, vec3 dir, float radius) {
    float b = dot(ori, dir);
    float c = -radius * radius + dot(ori, ori);
    float d = b * b - c;
    vec2 intersection = vec2(1e10, -1e10);
    if (d >= 0.0) {
        d = sqrt(d);
        intersection = vec2(-b - d, -b + d);
    }
    return intersection;
}

float IT_MiePhaseFunction(float g, float nu) {
    float gg = g * g;
    float k = 0.1193662 * (1.0 - gg) / (2.0 + gg);
    return k * (1.0 + nu * nu) * pow(1.0 + gg - 2.0 * g * nu, -1.5);
}

float IT_InterleavedGradientNoise(vec2 c) {
    return fract(52.9829189 * fract(0.06711056 * c.x + 0.00583715 * c.y));
}

vec2 IT_BlueNoiseTemproal() {
    return fract(texelFetch(noisetex, ivec2(gl_FragCoord.xy) % 64, 0).xy +
                 vec2(IT_GOLDEN_RATIO, IT_PLASTIC_RATIO) * vec2(frameCounter % 64));
}

// ---- Iteration T original EndSky.glsl functions (namespaced) ----
vec3 IT_CalculateStars(vec3 worldDir){
	float angleY = frameTimeCounter * 0.001 * (END_T_ANIMATION_SPEED * 0.01);
	mat3 eyeRoataionMatrixY = mat3(cos(angleY), 0, sin(angleY), 0, 1, 0, -sin(angleY), 0, cos(angleY));

	worldDir = eyeRoataionMatrixY * worldDir;

	const float scale = 384.0;
	const float coverage = 0.007;
	const float maxLuminance = 0.04;
	const float minTemperature = 4000.0;
	const float maxTemperature = 8000.0;

	//float visibility = IT_CURVE(IT_SATURATE(worldDir.y));

	float cosine = dot(IT_WORLD_SUN_VECTOR,  vec3(0, 0, 1));
	vec3 axis = cross(IT_WORLD_SUN_VECTOR,  vec3(0, 0, 1));
	float cosecantSquared = 1.0 / dot(axis, axis);
	worldDir = cosine * worldDir + cross(axis, worldDir) + (cosecantSquared - cosecantSquared * cosine) * dot(axis, worldDir) * axis;

	vec3  p = worldDir * scale;
	ivec3 i = ivec3(floor(p));
	vec3  f = p - i;
	float r = dot(f - 0.5, f - 0.5);

	vec3 i3 = fract(i * vec3(443.897, 441.423, 437.195));
	i3 += dot(i3, i3.yzx + 19.19);
	vec2 hash = fract((i3.xx + i3.yz) * i3.zy);
	hash.y = 2.0 * hash.y - 4.0 * hash.y * hash.y + 3.0 * hash.y * hash.y * hash.y;

	float c = IT_remapSaturate(hash.x, 1.0 - coverage, 1.0);
	return (maxLuminance * IT_remapSaturate(r, 0.25, 0.0) * c * c) * IT_Blackbody(mix(minTemperature, maxTemperature, hash.y));
}




vec3 IT_H(vec3 albedo, float a){
	vec3 R = sqrt(vec3(1.0) - albedo);
	vec3 r = (1.0 - R) / (1.0 + R);
	vec3 IT_H = r + (0.5 - r * a) * log((1.0 + a) / a);
	IT_H *= albedo * a;

	return 1.0 / (1.0 - IT_H);
}

vec3 IT_ppss(vec3 albedo, vec3 normal, vec3 eyeDir, vec3 lightDir, float s){
	float NdotL = dot(normal, lightDir);
	float NdotV = dot(normal, eyeDir);
	albedo *= IT_CURVE(IT_SATURATE(NdotL));

	vec3 color = albedo * IT_H(albedo, NdotL) * IT_H(albedo, NdotV) / (4.0 * IT_PI * (NdotL + NdotV));

	return IT_SATURATE(color);
}

float IT_Disc(float a, float s, float h){
	float disc = IT_CURVE(IT_SATURATE((a - (1.0 - s)) * h));
	return disc * disc;
}

void IT_PlanetEnd2(inout vec3 color, in vec3 eye, in vec3 rayDir, in vec3 lightDir, float planetIntensity){
	const float Rground = 20e6;
	const float Ratmo = 20.1e6;
	eye.y += Rground;
	eye.y += 15e6;

	float VdotL = dot(lightDir, rayDir);

	float mie = IT_MiePhaseFunction(0.8, VdotL);

	float angleX = -1.67079633 - radians(float(END_T_PLANET_ELEVATION));
	float angleY = IT_timeFactor;

	mat3 eyeRoataionMatrixX = mat3(1, 0, 0, 0, cos(angleX), -sin(angleX), 0, sin(angleX), cos(angleX));
	mat3 eyeRoataionMatrixY = mat3(cos(angleY), 0, sin(angleY), 0, 1, 0, -sin(angleY), 0, cos(angleY));
	mat3 eyeRoataionMatrix = eyeRoataionMatrixX * eyeRoataionMatrixY;

	float ringAngle = 0.0007084543;

	mat3 ringRoataionMatrix = mat3(1.0, 0.0, 0.0,
								   0.0, cos(ringAngle), sin(ringAngle),
								   0.0, -sin(ringAngle), cos(ringAngle));
	mat3 ringRoataionMatrixInverse = transpose(ringRoataionMatrix);



	rayDir = eyeRoataionMatrix * rayDir;
	lightDir = eyeRoataionMatrix * lightDir;

	// Geometric visibility of the black-hole light from the planet's skybox.
	// 0 means the planet fully occults the black hole; 1 means fully visible.
	float planetLightAlignment = dot(normalize(lightDir), vec3(0.0, -1.0, 0.0));
	float planetAngularRadius = asin(clamp(Rground / eye.y, 0.0, 1.0));
	float planetOccultation = smoothstep(cos(planetAngularRadius + radians(1.5)),
	                                     cos(planetAngularRadius - radians(1.5)),
	                                     planetLightAlignment);
	float planetLightVisibility = 1.0 - planetOccultation;

	vec3 rayDirRing = ringRoataionMatrix * rayDir;
	vec3 lightDirRing = ringRoataionMatrix * lightDir;

	vec3 ringOrigin = vec3(0.0, cos(ringAngle), sin(ringAngle)) * (eye.y / Rground);
	vec2 ringRadius = vec2(1.6, 2.6);



	vec3 surface = vec3(0.0);
	float LdotR = dot(rayDir, -lightDir);

	vec2 groundIntersection = IT_RaySphereIntersection(eye, rayDir, Rground);
	vec2 topAtmoIntersection = IT_RaySphereIntersection(eye, rayDir, Ratmo);


	vec3 surfacePos = rayDir * groundIntersection.x;
	vec3 surfaceNormal = normalize(surfacePos + vec3(0.0, eye.y, 0.0));

	if (groundIntersection.y > 0.0 && planetIntensity > 0.0){
		color *= 0.0;

		vec3 surfaceAlbedo = vec3(0.98, 0.87, 0.55);

		surface = IT_ppss(surfaceAlbedo, surfaceNormal, -rayDir, lightDir, 1.0);

		vec3 origin = ringOrigin + surfacePos / Rground;
		vec3 rayPos = IT_RayPlaneIntersection(origin, lightDirRing, vec3(0.0, 0.0, 1.0));
		float rayRadius = length(rayPos);

		if (rayRadius > ringRadius.x && rayRadius < ringRadius.y && dot(rayPos - origin, lightDirRing) > 0.0){
			const float octAlpha = 0.5;
			float octScale = 4.0;
			float octShift = (octAlpha / octScale) / 5;

			float accum = 0.0;
			float alpha = 0.5;
			float shift = 0.0;

			float position = rayRadius * 0.5 + 0.69;

			position += shift;

			for (int i = 0; i < 5; i++){
				accum += alpha * textureLod(noisetex, vec2(position, 0.0), 0.0).z;
				position = (position + shift) * octScale;
				alpha *= octAlpha;
			}

			surface *= exp(-pow(IT_SATURATE(accum + octShift - 0.1) * 1.5, 3.0) * smoothstep(ringRadius.x, ringRadius.x * 1.1, rayRadius));
		}


		float UdotN = IT_SATURATE(dot(ringRoataionMatrixInverse[2], surfaceNormal));
		float DdotN = IT_SATURATE(dot(-ringRoataionMatrixInverse[2], surfaceNormal));
		float OLdotN = IT_SATURATE(dot(ringRoataionMatrixInverse * normalize(vec3(-lightDir.xy, 0.0)), surfaceNormal));

		float ringLighting = IT_Disc(UdotN, 1.2, 1.5) * (1.0 - IT_Disc(UdotN, 3.4, 0.3));
		ringLighting += IT_Disc(DdotN, 1.2, 1.5) * (1.0 - IT_Disc(DdotN, 3.4, 0.3));
		ringLighting *= 1.0 - IT_Disc(OLdotN, 0.7, 1.3);

		surface += surfaceAlbedo * (1.5e-4 + ringLighting * 0.01);
	}

	if (topAtmoIntersection.y > 0.0){
		float isGround = step(0.0, groundIntersection.y);
		float thickness = (topAtmoIntersection.y - topAtmoIntersection.x - (groundIntersection.y - groundIntersection.x) * isGround) * 1e-7;
		float topAtmoMie = mie * thickness * thickness;
		topAtmoMie *= mix(1.0, smoothstep(0.9, 0.4, dot(surfaceNormal, normalize(eye))), isGround);
		topAtmoMie *= mix(0.04, 1.0, planetLightVisibility);
		surface += topAtmoMie * vec3(0.65, 0.7, 1.0);
	}

	color += surface * 0.6 * planetIntensity;


	float inRing = IT_SATURATE(abs(ringAngle) * 3000.0 - 0.8);
	float ring = 0.0;
	float transmittance = 1.0;

	if (abs(rayDirRing.z) > 0.000001) {
		float ringRayDistance = -ringOrigin.z / rayDirRing.z;
		if (ringRayDistance > 0.0) {
			vec3 ringPos = ringOrigin + rayDirRing * ringRayDistance;
			float rayRadius = length(ringPos.xy);
			bool planetBlocksRing = groundIntersection.y > 0.0
			                         && ringRayDistance * Rground > groundIntersection.x + 1.0;

			if (!planetBlocksRing && rayRadius > 1.6 && rayRadius < 2.6) {
				const float octAlpha = 0.5;
				float octScale = 4.0;
				float octShift = (octAlpha / octScale) / 5;
				float accum = 0.0;
				float alpha = 0.5;
				float shift = 0.0;
				float position = rayRadius * 0.5 + 0.69;
				position += shift;
				for (int i = 0; i < 5; i++) {
					accum += alpha * textureLod(noisetex, vec2(position, 0.0), 0.0).z;
					position = (position + shift) * octScale;
					alpha *= octAlpha;
				}
				ring += pow(IT_SATURATE(accum + octShift - 0.1) * 1.5, 3.0);
				ring *= smoothstep(1.6, 1.76, rayRadius);
				transmittance *= exp2(-ring * 3.0);
				float d = length(cross(lightDirRing, ringPos));
				ring *= 0.98 * max(smoothstep(0.8, 1.2, d), step(0.0, dot(lightDirRing, ringPos))) + 0.02;
			}
		}
	}
	ring = mix(planetLightVisibility * 0.49 + 0.01, ring, inRing);
	transmittance = mix(0.7, transmittance, inRing);

	color *= mix(1.0, transmittance, planetIntensity);

	ring *= 1.0 + mie * 10.0 * planetLightVisibility;
	ring *= mix(0.04, 1.0, planetLightVisibility);

	color += ring * 0.012 * vec3(1.0, 0.85, 0.60) * planetIntensity;
}



//www.shadertoy.com/view/lstSRS

mat3 IT_RotateMatrix(float x, float y, float z){
	mat3 matx = mat3(1.0, 0.0, 0.0,
					 0.0, cos(x), sin(x),
					 0.0, -sin(x), cos(x));

	mat3 maty = mat3(cos(y), 0.0, -sin(y),
					 0.0, 1.0, 0.0,
					 sin(y), 0.0, cos(y));

	mat3 matz = mat3(cos(z), sin(z), 0.0,
					 -sin(z), cos(z), 0.0,
					 0.0, 0.0, 1.0);

	return maty * matx * matz;
}

void IT_WarpSpace(inout vec3 eyevec, inout vec3 raypos){
	vec3 origin = vec3(0.0, 0.0, 0.0);

	float singularityDist = distance(raypos, origin);
	float warpFactor = 1.0 / (singularityDist * singularityDist + 0.000001);

	vec3 singularityVector = normalize(origin - raypos);

	float warpAmount = 0.06 * (END_T_WARP_STRENGTH * 0.01);

	eyevec = normalize(eyevec + singularityVector * warpFactor * warpAmount);
}


float IT_Calculate3DNoise(vec3 position){
	vec3 p = floor(position);
	vec3 b = IT_CURVE(fract(position));

	vec2 uv = 17.0 * p.z + p.xy + b.xy;
	vec2 rg = textureLod(noisetex, (uv + 0.5) / 64.0, 0.0).zx;

	return mix(rg.x, rg.y, b.z);
}

float IT_CalculateCloudFBM(vec3 position, vec3 shift){
	const int octaves = 4;
	const float octAlpha = 0.87;
	const float octScale = 2.5;
	const float octShift = (octAlpha / octScale) / octaves;

	float accum = 0.0;
	float alpha = 0.5;

	for (int i = 0; i < octaves; i++) {
		accum += alpha * IT_Calculate3DNoise(position);
		position = (position + shift) * octScale;
		alpha *= octAlpha;
	}

	return accum + octShift;
}



float IT_pcurve(float x){
	float x2 = x * x;
	return 12.207 * x2 * x2 * (1.0 - x);
}

void IT_BlackHole_AccretionDisc_Stars(inout vec3 color, out vec3 stars, in vec3 rayDir, in vec3 lightDir){
	stars = vec3(0.0);
	const float steps = 50.0;
	const float rSteps = 1.0 / steps;
	const float stepLength = 0.2;

	const float discRadius = 2.25;
	const float discWidth = 3.5;
	const float discInner = discRadius - discWidth * 0.5;
	const float discOuter = discRadius + discWidth * 0.5;

	#ifdef TAA
		float noise = IT_BlueNoiseTemproal().x;
	#else
		float noise = IT_InterleavedGradientNoise(gl_FragCoord.xy);
	#endif

	vec3 eye = -lightDir * 8.0;
	vec3 rayPos = eye + rayDir * 3.0;

	mat3 rotation = IT_GetSkyAnchoredDiscRotation(lightDir);


	vec3 result = vec3(0.0);
	float transmittance = 1.0;

	rayPos += rayDir * stepLength * noise;

	for(int i = 0; i < steps; i++){
		if(transmittance < 0.0001) break;

		IT_WarpSpace(rayDir, rayPos);
		rayPos += rayDir * stepLength;

		{
			vec3 discPos = rotation * rayPos;

			float r = length(discPos);
			float p = IT_atan2(-discPos.zx);
			float h = discPos.y;

			float radialGradient = 1.0 - IT_SATURATE((r - discInner) / discWidth * 0.5);
			float dist = abs(h);

			float discThickness = 0.1 * radialGradient;

			float fr = abs(r - discInner) + 0.4;
			fr = fr * fr;
			float fade = fr * fr * 0.04;
   			float bloomFactor = 1.0 / (h * h * 40.0 + fade + 0.00002);
			bloomFactor *= IT_SATURATE(2.0 - abs(dist) / discThickness);
			bloomFactor = bloomFactor * bloomFactor;


			float dr = IT_pcurve(radialGradient);
			float density = dr;

			density *= IT_SATURATE(1.0 - abs(dist) / discThickness);
			density = IT_SATURATE(density * 0.7);
			density = IT_SATURATE(density + bloomFactor * 0.1);

			if (density > 0.0001){
				#ifdef END_T_DETAIL_LONGITUDE
					vec3 discCoord = vec3(r, p * (1.0 - radialGradient * 0.5), h * 0.1) * 3.5;
					float fbm = IT_CalculateCloudFBM(discCoord, frameTimeCounter * vec3(0.1, 0.07, 0.0) * (END_T_ANIMATION_SPEED * 0.01));
				#else
					vec3 discCoord = vec3(r, 0.0, h * 0.1) * 3.5;
					float fbm = IT_CalculateCloudFBM(discCoord, frameTimeCounter * vec3(0.03, 0.05, 0.0) * (END_T_ANIMATION_SPEED * 0.01));
				#endif
				fbm = fbm * fbm;
				fbm = fbm * fbm;

				density *= fbm * dr;

				float gr = 1.0 - radialGradient;
				gr = gr * gr;
				float glowStrength = 1.0 / (gr * gr * 400.0 + 0.002);
				vec3 glow = IT_Blackbody(2700.0 + glowStrength * 50.0) * glowStrength;

				#ifdef END_T_DOPPLER_EFFECT
					glow *= sin(p - 1.07) * 0.75 + 1.0;
				#endif
				
				float stepTransmittance = exp2(-density * 7.0);
				float integral = 1.0 - stepTransmittance;
				transmittance *= stepTransmittance;

				result += integral * transmittance * glow;
			}

			vec2 t = vec2(1.0, 0.01);
			float torusDist = length(length(discPos + vec3(0.0, -0.05, 0.0)) - t);
			float bloomDisc = 1.0 / (pow(torusDist, 3.5) + 0.001);
			vec3 col = IT_Blackbody(12000.0);
			bloomDisc *= step(0.5, r);

			result += col * bloomDisc * 0.1 * transmittance;
		}
	}
	result *= rSteps;

	#if END_T_STARS > 0
		stars = IT_CalculateStars(rayDir) * transmittance;
	#endif

	color *= transmittance;

	color += result;
}




// Scene orientation controls. Zero rotation/tilt reproduces Iteration T's original axes.
vec3 IT_AdjustDirectionElevation(vec3 direction, float elevationOffset) {
    vec3 d = normalize(direction);
    float azimuth = atan(d.x, d.z);
    float elevation = asin(clamp(d.y, -1.0, 1.0)) + radians(elevationOffset);
    return normalize(vec3(cos(elevation) * sin(azimuth),
                          sin(elevation),
                          cos(elevation) * cos(azimuth)));
}

mat3 IT_GetSceneRotation() {
    float yaw = radians(130.0 + float(END_T_SKY_ROTATION));
    float pitch = radians(float(END_T_SKY_TILT));
    mat3 rotY = mat3(cos(yaw), 0.0, -sin(yaw),
                     0.0, 1.0, 0.0,
                     sin(yaw), 0.0, cos(yaw));
    mat3 rotX = mat3(1.0, 0.0, 0.0,
                     0.0, cos(pitch), sin(pitch),
                     0.0, -sin(pitch), cos(pitch));
    return rotY * rotX;
}

mat3 IT_RotateAroundAxis(vec3 axis, float angle) {
    axis = normalize(axis);
    float c = cos(angle);
    float si = sin(angle);
    float t = 1.0 - c;
    float x = axis.x;
    float y = axis.y;
    float z = axis.z;
    // Rodrigues rotation matrix (GLSL column-major constructor order).
    return mat3(
        c + x*x*t,       y*x*t + z*si, z*x*t - y*si,
        x*y*t - z*si,    c + y*y*t,    z*y*t + x*si,
        x*z*t + y*si,    y*z*t - x*si, c + z*z*t
    );
}

mat3 IT_GetSkyAnchoredDiscRotation(vec3 lightDir) {
    // Build a stable local tangent frame at the black hole's direction in the sky.
    // These axes depend only on the black-hole direction and world-up, not the camera.
    mat3 sourceDiscRotation = IT_RotateMatrix(0.1, 0.0, -0.35);
    vec3 blackHoleSkyDirection = normalize(lightDir);
    vec3 worldUpReference = vec3(0.0, 1.0, 0.0);

    vec3 skyRight = cross(worldUpReference, blackHoleSkyDirection);
    if (dot(skyRight, skyRight) < 0.000001) {
        skyRight = cross(vec3(0.0, 0.0, 1.0), blackHoleSkyDirection);
    }
    skyRight = normalize(skyRight);
    vec3 skyUp = normalize(cross(blackHoleSkyDirection, skyRight));

    // Zero Up/Down corresponds to the original -55-degree disc baseline;
    // the default -10 dial offset yields a -65-degree disc orientation. Control values are offsets from this baseline.
    mat3 leftRightTilt = IT_RotateAroundAxis(skyUp, radians(float(END_T_DISC_TILT_LEFT_RIGHT)));
    mat3 upDownTilt = IT_RotateAroundAxis(skyRight, radians(-55.0 + float(END_T_DISC_TILT_UP_DOWN)));
    mat3 skyAnchoredCorrection = upDownTilt * leftRightTilt;

    // Keep the raymarch coordinates in Iteration T's original local frame.
    return sourceDiscRotation * transpose(skyAnchoredCorrection);
}

// Derive the sky colour grade from the same End-light colour used by
// lightAndAmbientColors.glsl. Neutrality 100 keeps the sky unchanged; lower
// values apply a progressively stronger purple tint, with the maximum at neutrality 0.
vec3 IT_GetEndSkyLightTint() {
    vec3 endLightColorBase = vec3(0.68, 0.51, 1.07);

    // Euphoria optionally blends End lighting with its fog colour. Mirror that
    // same base-colour calculation so the sky grade matches the actual light.
    #ifdef END_SKY_FOG_INFLUENCE
        float endFogLumina = dot(fogColor, vec3(0.299, 0.587, 0.114));
        vec3 endLightTempC = vec3(0.68, 0.51, 1.07);
        endLightColorBase = clamp(
            mix(endLightTempC,
                fogColor * 0.6 + 0.3 * normalize(fogColor + 0.0001) + (0.25 - 0.25 * endFogLumina),
                (1.0 - inVanillaEnd) * float(END_SKY_FOG_INFLUENCE)),
            0.0, 1.5
        );
    #endif

    float endLightLuma = dot(max(endLightColorBase, vec3(0.0)), vec3(0.2126, 0.7152, 0.0722));
    vec3 endLightNeutral = endLightLuma * vec3(1.0, 0.98, 0.94);
    vec3 endLightColor = mix(endLightColorBase, endLightNeutral, END_T_LIGHT_NEUTRAL * 0.01);

    // Convert the final light colour to a hue, then express it relative to the
    // neutral hue. This makes the 100 setting exactly identity while keeping
    // the same purple direction as End lighting as neutrality is reduced.
    float lightMax = max(max(endLightColor.r, endLightColor.g), endLightColor.b);
    float neutralMax = max(max(endLightNeutral.r, endLightNeutral.g), endLightNeutral.b);
    vec3 lightHue = endLightColor / max(lightMax, 0.0001);
    vec3 neutralHue = endLightNeutral / max(neutralMax, 0.0001);
    vec3 skyTint = lightHue / max(neutralHue, vec3(0.0001));

    // Double the purple saturation around the tint's luminance, preserving
    // brightness. At neutrality 100, skyTint is exactly white, so this remains
    // an identity transform with no sky tint. Limit the boost only if an
    // Euphoria fog colour would otherwise push a channel below zero.
    float skyTintLuma = dot(max(skyTint, vec3(0.0)), vec3(0.2126, 0.7152, 0.0722));
    vec3 skyTintChroma = skyTint - vec3(skyTintLuma);
    float chromaBoost = 2.0;
    if (skyTintChroma.r < 0.0) chromaBoost = min(chromaBoost, skyTintLuma / -skyTintChroma.r);
    if (skyTintChroma.g < 0.0) chromaBoost = min(chromaBoost, skyTintLuma / -skyTintChroma.g);
    if (skyTintChroma.b < 0.0) chromaBoost = min(chromaBoost, skyTintLuma / -skyTintChroma.b);
    return max(vec3(skyTintLuma) + skyTintChroma * chromaBoost, vec3(0.0));
}

vec3 IT_GetEndSkyLinear(vec3 worldRay) {
    mat3 sceneRotation = IT_GetSceneRotation();
    mat3 inverseSceneRotation = transpose(sceneRotation);
    vec3 rayDir = normalize(inverseSceneRotation * normalize(worldRay));
    vec3 lightDir = IT_AdjustDirectionElevation(IT_WORLD_SUN_VECTOR, float(END_T_BLACK_HOLE_ELEVATION));
    vec3 result = vec3(0.0);

    #if END_T_BLACK_HOLE > 0 || END_T_STARS > 0
        vec3 discRadiance = vec3(0.0);
        vec3 starRadiance = vec3(0.0);
        IT_BlackHole_AccretionDisc_Stars(discRadiance, starRadiance, rayDir, lightDir);
        #if END_T_BLACK_HOLE > 0
            result += discRadiance * (END_T_BLACK_HOLE_INTENSITY * 0.01);
        #endif
        #if END_T_STARS > 0
            result += starRadiance * (END_T_STAR_INTENSITY * 0.01);
        #endif
    #endif

    #if END_T_PLANET > 0
        if (END_T_PLANET_INTENSITY > 0) {
            IT_PlanetEnd2(result, vec3(0.0), rayDir, lightDir, END_T_PLANET_INTENSITY * 0.01);
        }
    #endif

    // Iteration T stores its sky in a 1/2048 curve-encoded buffer, then
    // restores the scale and applies an 8.5x exposure in Final.glsl.
    // Complementary/Euphoria instead gamma-encodes this sky and sends it
    // through its own scene-linear tonemapper. Pass the equivalent scene
    // radiance to that pipeline (without I.T.'s intermediate buffer factor).
    // Apply the End-light hue once after all sky elements have been composed,
    // so stars, the planet and black hole always share one consistent colour grade.
    result *= IT_GetEndSkyLightTint();
    return max(result, vec3(0.0)) * 8.5 * (END_T_SKY_BRIGHTNESS * 0.01);
}

// G-buffer/deferred colour attachments are gamma-encoded by Complementary,
// then converted to linear by composite1.glsl (pow(color, 2.2)).
vec3 IT_GetEndSkyGamma(vec3 worldRay) {
    return pow(max(IT_GetEndSkyLinear(worldRay), vec3(0.0)), vec3(1.0 / 2.2));
}

// Reflection calculations are already in the linear-light part of the pipeline.
vec3 IT_GetEndSkyReflectionGamma(vec3 worldRay) {
    // Complementary's reflectionBackground path blends End sky colours in its
    // gamma-encoded material colour space (the existing volumetric term is
    // explicitly pow(1/2.2) before this blend), so keep the same transfer here.
    return IT_GetEndSkyGamma(worldRay);
}

#endif // ITERATION_T_END_SKY_MODULE
